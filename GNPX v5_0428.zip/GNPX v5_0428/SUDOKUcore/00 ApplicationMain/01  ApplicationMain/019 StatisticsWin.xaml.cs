﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;
using System.Text;
using System.Xml.Linq;
using System.Windows.Threading;

using static System.Math;
using static System.Diagnostics.Debug;

using GIDOO_space;

namespace GNPXcore{
    using pRes=Properties.Resources;
    public partial class StatisticsWin: Window{
        private NuPz_Win            pGNP00win;
        public  GNPZ_Graphics       SDKGrp;
        private RenderTargetBitmap  bmpGZero;
        private List<UCell>         ppBDL;
        private bool                sNoAssist=true;

        public  GNPX_App            pGNP00 => pGNP00win.GNPX_000;
        private GNPZ_Engin          pGNPX_Eng => pGNP00.pGNPX_Eng;
        private GNPX_AnalyzerMan    pAnMan => pGNPX_Eng.AnMan;

        private PuzzleTrans         PTrans;

        private UPuzzle             P0_dev;
        private UPuzzle             P1_sol;
        private DispatcherTimer     onWorkingTimer;
        private int                 onWorkingCounter=0;

        static private string       pathName = "develop/";


        private string              fName_Transformed_1Removed        => pathName+"hardSuDoKu_Transformed_1Removed.txt";
        private string              fName_Transformed_12Added         => pathName+"hardSuDoKu_Transformed_12Added.txt";
        private string              fName_Transformed_X = null;
        private string              fName_CharacteristicAnalysis      => pathName+"hardSuDoKu_CharacteristicAnalysis.txt";

        private string              fName_GNPX_Solution               => pathName+ "hardSuDoKu_GNPX_Solution.txt";
        private string              fName_TryAndError_Solution        => pathName+ "hardSuDoKu_TryAndError_Solution.txt";
        private string              fName_TryAndError_SolutionSummary => pathName+ "hardSuDoKu_TryAndError_SolutionSummary.txt";        
        private ALSLinkMan          ALSMan;

    #region Main, Service
        public StatisticsWin( NuPz_Win pGNP00win ){
            InitializeComponent();
            GNPXGNPX.Content = G.GNPXvX;
            this.MouseLeftButtonDown += (sender, e) => this.DragMove();

            this.pGNP00win = pGNP00win;           

            SDKGrp = new GNPZ_Graphics(pGNP00win.GNPX_000);
            bmpGZero = new RenderTargetBitmap((int)dev_GBoard.Width,(int)dev_GBoard.Height, 96,96, PixelFormats.Default);

            SDKGrp.GBoardPaint(bmpGZero, (new UPuzzle()).BOARD);
            dev_GBoard.Source = bmpGZero;

            PTrans = new PuzzleTrans(pGNP00);


            onWorkingTimer = new DispatcherTimer(DispatcherPriority.Normal, this.Dispatcher);
            onWorkingTimer.Interval = TimeSpan.FromMilliseconds(100);
            onWorkingTimer.Tick += new EventHandler(onWorkingTimer_Tick);
        }

        private void onWorkingTimer_Tick(object sender, EventArgs e ){
            onWorkingCounter++;
            onWorkingCounter %= 5;

            WriteLine( $"onWorkingCounter:{onWorkingCounter}");
        }

        private void devWinClose_Click(object sender, RoutedEventArgs e){
            this.Hide();
        }
    #endregion Main, Service


    #region read, deform


        public void Set_dev_GBoard( List<UCell> pBOARD, bool dispOn=false ){
            ppBDL = pBOARD;
            pAnMan.Update_CellsState(ppBDL, setAllCandidates:true);
            SDKGrp.GBoardPaint( bmpGZero, pBOARD, sNoAssist:sNoAssist);
            dev_GBoard.Source = bmpGZero;
        }
        private void devWin_IsVisibleChanged( object sender, DependencyPropertyChangedEventArgs e ){
            if(ppBDL==null)  return;
            SDKGrp.GBoardPaint( bmpGZero, ppBDL, sNoAssist:true );
            dev_GBoard.Source = bmpGZero;
        }


    #endregion read, deform       
   
        private void CharacteristicAnalysis_Click(object sender, RoutedEventArgs e) {

            using( var fpW=new StreamWriter(fName_CharacteristicAnalysis, false, Encoding.UTF8) ){
                int[] numLst = new int[10];
                
                foreach( var P in P0_dev.BOARD ){
                    int n = P.FreeBC;
                    numLst[n]++;
                }
                string st = "number of elements:";
                for( int n=0; n<10; n++ )  st += $" {n}:{numLst[n]}";
                fpW.WriteLine( st ); 
                WriteLine( st );
            }
        }



    #region SaveBitMap
        private void SaveBitMap_Click( object sender, RoutedEventArgs e ){
            BitmapEncoder enc = new PngBitmapEncoder(); // JpegBitmapEncoder(); BmpBitmapEncoder();
            BitmapFrame bmf = BitmapFrame.Create(bmpGZero);
            enc.Frames.Add(bmf);
            try{
                Clipboard.SetData(DataFormats.Bitmap,bmf);
            }
            catch(System.Runtime.InteropServices.COMException){ /* NOP */ }

            if( !Directory.Exists(pRes.fldSuDoKuImages) ){ Directory.CreateDirectory(pRes.fldSuDoKuImages); }
            string fName=DateTime.Now.ToString("yyyyMMdd HHmmss Develop")+".png";
            using( Stream stream = File.Create(pRes.fldSuDoKuImages+"/"+fName) ){
                enc.Save(stream);
            }      
            
            lblMessafg.Content = "saved:"+ fName;
        }
    #endregion SaveBitMap



    }
}
