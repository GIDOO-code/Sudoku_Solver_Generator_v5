﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

using static System.Math;
using static System.Diagnostics.Debug;

using System.Windows.Media;
using System.Threading;

using GIDOO_space;
using System.Globalization;
using System.Text.RegularExpressions;
//using System.Drawing;
//using System.Drawing;


namespace GNPXcore{

    public class UMthdChked{
	    public UAlgMethod UAM;
        public int    ID{ get; set; }
        public string Name{ get; set; }
        public bool   IsChecked{ get=>UAM.IsChecked; set=>UAM.IsChecked=value;  }

        public int    __difficultyLevel;  //(difficulty)

        public UMthdChked( UAlgMethod P ){
            this.UAM=P; this.ID=P.ID; Name=P.MethodName; IsChecked=P.IsChecked;
        }
    }


    public partial class GNPX_App{
		readonly char[] sep=new char[]{' ',','};

        public List<UMthdChked> ReadFile_MethodList_AnalysisConditions( ){
            if(SolverLst1==null) new List<UAlgMethod>();
            else SolverLst1.Clear();

            SolverLst1.AddRange(pGNPX_Eng.AnMan.SolverLst0);
            SolverLst1.ForEach(P=>P.IsChecked=true);


            string st;
            int IDx=0, intResult=0;
            bool boolResult;
            var  culture = CultureInfo.CreateSpecificCulture("en-US");
            var  styles = DateTimeStyles.None;
            DateTime dateResult = DateTime.Now;

            if( File.Exists(SDK_MethodsFileName) ){
                using( var fIn=new StreamReader(SDK_MethodsFileName) ){
                    while( (st=fIn.ReadLine()) !=null ){
                        if( st.Contains("abortResult") ) continue;
                        bool bChk = true;

                        if( st[0]=='*' ){
                            if( st[1] == '*' ) continue;

                            var mLst= st.Split(sep,StringSplitOptions.RemoveEmptyEntries);
                            string key = mLst[0].Substring(1);
                            string st2 = (mLst.Length>1)? mLst[1]: "";
 
                            if( st2.IsNumeric() )  GMthdOption[key] = st2.ToInt();
                            else if( int.TryParse(st2,out intResult) )  GMthdOption[key] = intResult;
                            else if( bool.TryParse(st2,out boolResult) )  GMthdOption[key] = boolResult;
                            else if( st2=="True" || st2=="False" )  GMthdOption[key] = st2=="True";
                            else if( DateTime.TryParse(st2, culture, styles, out dateResult) ){
                                GMthdOption[key] = dateResult;
                            }
                            else GMthdOption[key] = st2;
                        }
                        else{
                            if(st[0]=='-'){ bChk=false; st=st.Substring(1); }
                            UAlgMethod Q= SolverLst1.Find(x=>x.MethodName.Contains(st));
                            if(Q is UAlgMethod){ Q.ID=IDx++; Q.IsChecked=bChk; }
                        }
                    }
                }
            }
            SolverLst1.Sort( (p,q)=>(p.ID-q.ID) );

            Set_MethodLis_1to2(FileOutput:false);
            return SolverLst2;
        }

        public void OutPut_MethodList( ){
//X            if( _Loading_ || SolverLst1 == null || SolverLst1.Count<=1 ) return;
            if( SolverLst1 == null || SolverLst1.Count<=1 ) return;

            using( var fOut=new StreamWriter(SDK_MethodsFileName,append:false,encoding:Encoding.UTF8) ){
                string st="";
                SolverLst1.ForEach( P=>{ 
                    st=(P.IsChecked? "": "-")+P.MethodName.TrimStart( ' ');
                    fOut.WriteLine(st); 
                });

                foreach( var P in GNPX_App.GMthdOption.Where(p=>p.Key!="abortResult" ) ){
                    fOut.WriteLine("*"+P.Key +" "+P.Value );
                }
            }

            var Qabort = (string)GNPX_App.GMthdOption["abortResult"];
            if( Qabort != "" ){
                using( var fAbort=new StreamWriter("Report_of_Cancellation.txt",append:false,encoding:Encoding.UTF8) ){
                    fAbort.WriteLine( $"\nabort Time:{DateTime.Now}\n  {Qabort}" );
                }
                GNPX_App.GMthdOption["abortResult"] = "";
            }

            bool B = (bool)GNPX_App.GMthdOption["GeneralLogic_on"];
			var QLst = SolverLst1.FindAll(x=>x.MethodName.Contains("GeneralLogic"));
			QLst.ForEach( Q => Q.IsChecked=B );

            var Q2Lst=SolverLst2.FindAll(x=>x.Name.Contains("GeneralLogic"));
			Q2Lst.ForEach( Q => Q.IsChecked=B );

            WriteLine( $"===== OutPut_MethodList() ... done" +  DateTime.Now.ToString("G") );
        }


        public List<UMthdChked> Reset_MethodList(){
            int IDx=0;
            if(SolverLst1==null) new List<UAlgMethod>();
            else SolverLst1.Clear();

            SolverLst1.AddRange(pGNPX_Eng.AnMan.SolverLst0);
            SolverLst1.ForEach(P=> { P.IsChecked=true; P.ID=IDx++; });

            Set_MethodLis_1to2(true);
            return SolverLst2;
        }


        public List<UMthdChked> Set_MethodLis_1to2( bool FileOutput ){
            if( SolverLst1==null || SolverLst1.Count==0 )  return null;
            SolverLst2 = SolverLst1.ConvertAll(Q=>new UMthdChked(Q));

            if(FileOutput)  OutPut_MethodList();
            return SolverLst2;
        }


        public List<UMthdChked> ChangeOrder_MethodList( int nx, int UD ){
            UAlgMethod MA=SolverLst1[nx], MB;
            if(UD<0){ MB=SolverLst1[nx-1]; SolverLst1[nx-1]=MA; SolverLst1[nx]=MB; }   
            if(UD>0){ MB=SolverLst1[nx+1]; SolverLst1[nx+1]=MA; SolverLst1[nx]=MB; }
            Set_MethodLis_1to2(FileOutput:true);
            return SolverLst2;
        }



    }

}