using System;
using System.Linq;
using System.Collections.Generic;
using static System.Diagnostics.Debug;
using System.Globalization;

using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Input;

using System.Resources;
using System.Runtime.InteropServices;
using System.Diagnostics;
using GNPXcore;

namespace GIDOO_space{
    static public class ULogical_Node_Utility{     
        static private UInt128[]     pHouseCells81     = AnalyzerBaseV2.HouseCells81;
        static private UInt128[]     pConnectedCells81 = AnalyzerBaseV2.ConnectedCells81;


		static private readonly int[]   _rcbFrame_Value;

        static public int func_rcbFrame_Value( this int rc) => (1<<(rc.ToBlock()+18)) | (1<<(rc%9+9)) | (1<<rc/9);
		static public int rcbFrame_Value( this int rc) => _rcbFrame_Value[rc];
        static public int Ceate_rcbFrameAnd( this UInt128 b081 )  => b081.IEGet_rc().Aggregate( 0x7FFFFFF, (p,q) => p&rcbFrame_Value(q) );
        static public int Ceate_rcbFrameOr( this UInt128 b081 )   => b081.IEGet_rc().Aggregate( 0, (p,q) => p|rcbFrame_Value(q) );
        static public UInt128 Aggregate_ConnectedAnd( this UInt128 B) => B.IEGet_rc().Aggregate( (UInt128.One<<81)-1, (b,rc)=>b&pConnectedCells81[rc] );
        static public UInt128 Aggregate_ConnectedAnd( this ULogical_Node ULGN ) => ULGN.b081.Aggregate_ConnectedAnd();


		static ULogical_Node_Utility(){
			_rcbFrame_Value = new int[81];
			for( int rc=0; rc<81; rc++ )  _rcbFrame_Value[rc] = func_rcbFrame_Value(rc);
		}
    }

    static public partial class GNPZExtender{
		static private readonly UInt128 _filter0081 = (UInt128.One<<81)-1;    // b081
        static private readonly UInt128 qZero = UInt128.Zero;
        static private readonly UInt128 qOne  = UInt128.One;
        static private readonly UInt128 _b9   = 0x1FF;

        //========================================================================
        // Note: UInt128 instance variables do not change the original variable.
        //========================================================================
        static public UInt128 DifSet( this UInt128 A, UInt128 B ) => (UInt128)(A&(B^UInt128.MaxValue)); // A = (UInt128)(A&(B^UInt128.MaxValue));
        static public UInt128 Set( this UInt128 A, int rc )       => A | qOne<<rc;                      // A = A | qOne<<rc;
        static public UInt128 Set( this UInt128 A, UInt128 B )    => A | B;                             // A = A | B;
        static public UInt128 Reset( this UInt128 A, int rc )     => A & ((qOne<<rc)^UInt128.MaxValue); // A = A & (qOne<<rc)^UInt128.MaxValue;

        static public UInt128 Reset( this UInt128 A, UInt128 B )  => A & B^UInt128.MaxValue;            // A = A & B^UInt128.MaxValue;
        static public bool IsHit( this UInt128 A, int rc )        => (A & (qOne<<rc)) != qZero;
        static public bool IsHit( this UInt128 A, UInt128 B )     => (A & B) != qZero;

        static public bool IsZero( this UInt128 A )               => (A == qZero); 
    
        static public bool IsNotZero( this UInt128 A )            => (A != qZero);

        static public int FindFirst_rc( this UInt128 A ){
            UInt128 w = A & _filter0081;
            for( int rc=0; rc<81; rc++ ){
                if( (w&0x1FF) == 0 ){ w>>=9; rc+=8; continue;}
                if( (w&UInt128.One)>0 )  return rc;
                w >>= 1;
            }
            return -1;
        }

        static public int BitToNum( this UInt128 U128, int sz ){    
            if(U128.BitCount()!=1) return -1;
            for( int k=0; k<sz; k+=8 ){
                uint w = ((uint)(U128>>k)) & 0xFF;
                if( w == 0 )  continue;
                for( int n=0; n<8; n++ ){
                    if( (w & (1<<n)) > 0 ) return (k+n);
                }
            }
            return -1;
        } 


        static public string ToBitStringWSP( this int num, int ncc, bool with_sp ){
            int numW = num;
            string st="";
            for(int k=0; k<ncc; k++ ){
                st += ((numW&1)!=0)? ((k%9)+1).ToString(): ".";
                if(k==8)  st += " ";
                numW >>= 1;
            }
            return st;
        }

        static public string ToBitString81( this UInt128 A ){
            string st="";
            for(int n=0; n<3; n++){
                int bp = (int)( A >> (n*27) );
                int tmp=1;
                for(int k=0; k<27; k++){
                    st += ((bp&tmp)>0)? "1": "."; //External expression
                    tmp = (tmp<<1);
                    if(k==26)         st += " /";
                    else if((k%9)==8) st += " ";
                }
            }
            return st;
        }
        static public string ToBitString81N( this UInt128 A){
            string st="";
            for(int n=0; n<3; n++){
                int bp = (int)( A >> (n*27) );
                int tmp=1;
                for(int k=0; k<27; k++){
                  //st += ((bp&tmp)>0)? ((k%9)+0).ToString(): "."; //Internal expression
                    st += ((bp&tmp)>0)? ((k%9)+1).ToString(): "."; //External expression
                    tmp = (tmp<<1);
                    if(k==26)         st += " /";
                    else if((k%9)==8) st += " ";
                }
            }
            return st;
        }
        static public string ToBitString128( this UInt128 A, int size=128 ){
            string st="";
              
            UInt128 w = A;
            for(int k=0; k<size; k++){
                st += (w&1)>0? $"1": "."; 
                if( k%8==7 ) st += " ";
                w >>=1 ;
            }
            return st;
        }
        static public string ToStringN( this UInt128 A ){
            string st="";
              
            UInt128 w = A;
            for(int k=0; k<128; k++){
                st += (w&1)>0? $"{k%8+1}": "."; 
                if( k%8==7 ) st += " ";
                w >>=1 ;
            }
            return st;
        }

		static public string ToString( this (UAnLS,int) UA_no ){
			var (UA,no) = UA_no;
			string st = $"no:{no.ToBitString()}\nUA:{UA}";
			return st;		
		}

        static public string ToBitString128(this UInt128? A, int size=128){
            string st = "";

            UInt128? w = A;
            for( int k=0; k<size; k++ ){
                st += (w&1)>0? $"1" : ".";
                if( k%8==7 ) st += " ";
                w >>= 1;
            }
            return st;
        }
        static public IEnumerable<int> IEGetRC( this UInt128 U, int mx=81){
            UInt128  B = U;
            for(int m=0; m<mx; m++){
                if( (B&1)>0 ) yield return m;
                B = B>>1;
            }
        }
        static public IEnumerable<UCell> IEGetUCell_noB( this UInt128 bp, List<UCell> pBOARD, int noBX ){ //nx=0...8        
            for(int k=0; k<81; k++ ){
                if( ((bp>>k)&1)==0 ) continue;
                UCell P = pBOARD[k];
                if( (P.FreeB&noBX) > 0 )  yield return P;
            }
        }

        static public string ToRCStringComp( this UInt128 U, string msg="", int mx=81){
            var stRCList = U.IEGetRC(mx:81).ToList().ConvertAll( p=>p.ToRCString() );
            string st = string.Join(' ',stRCList);
            return st.ToString_SameHouseComp()+msg;
        }
		static public string ToRCStringComp( this UInt128 U, int freeB, int mx=81){
			return ToRCStringComp( U, " #"+freeB.ToBitStringN(9) );
		}

        static public int  UInt128AggregateFreeB( this UInt128 U, List<UCell> XLst ) => U.IEGet_rc().Aggregate(0,(Q,q)=>Q|XLst[q].FreeB);

        static public void UInt128_test(){

            for( int k=0; k<128; k++ ){
                UInt128 A1 = UInt128.One<<k;
                int k2 = A1.BitToNum(128);
                if( k != k2 )  WriteLine( $"k:{k} k2:{k2}  A1:{A1.ToBitString128()}" );
            }
          
			UInt128 A=0;
            UInt128 B = A.Set(2);           WriteLine( $"A:{A.ToBitString128(size:16)}  B:{B.ToBitString128(size:16)}");
            UInt128 C=15, D= C.DifSet(2);   WriteLine( $"C:{C.ToBitString128(size:16)}  D:{D.ToBitString128(size:16)}");
            UInt128 E=15, F= E.Reset(2);    WriteLine( $"E:{E.ToBitString128(size:16)}  F:{F.ToBitString128(size:16)}");


			A=0; B=6; C=1<<19; D=UInt128.One<<79;
			WriteLine( $"A:{A.ToBitString81()}");
			WriteLine( $"B:{B.ToBitString81()}");
			WriteLine( $"C:{C.ToBitString81()}");
			WriteLine( $"D:{D.ToBitString81()}");

			A |= 1<<5; A |= D;
			WriteLine( $"A:{A.ToBitString81()}");
			WriteLine( $"A:{A.ToBitString81()}");
			A = 0xFF;
			WriteLine( $"A:{A.ToBitString81()}");
			B = A.DifSet(1<<3);
			WriteLine( $"A:{A.ToBitString81()}");
			WriteLine( $"B:{B.ToBitString81()}");
        }
/*
        static public List<string> Find_Duplicate(  
        list.GroupBy(x => x)
                        .Where(g => g.Count() > 1)
                        .Select(x => x.Key)
                        .ToList();
*/
    }
}