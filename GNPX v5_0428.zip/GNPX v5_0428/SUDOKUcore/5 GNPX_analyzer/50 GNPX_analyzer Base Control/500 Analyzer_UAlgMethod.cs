using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Media;
using System.Threading;
using static System.Diagnostics.Debug;
using static System.Math;
using System.Security.Cryptography;
using System.Windows.Interop;
using System.IO;
using System.Text;

namespace GNPXcore{
    using pRes=Properties.Resources;
    public delegate bool dSolver();

    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
    public class UAlgMethod{
        static private  int     ID0=0;
        public			int     ID;          // for ordering
        public readonly int     recm;
		public readonly dSolver Method;
        public readonly string  MethodName;
        public readonly string	MethodKey;

        // For algorithms with negative levels, there are simpler conjugate algorithms.
        // If you just solve Sudoku, you don't need it. For example, the 5D-LockedSet is conjugate with the 4D-LockedSet.
        public readonly int    difficultyLevel=-1;         // Level of difficulty


        public bool       GenLogB;          // "GeneralLogic"
        public int        UsedCC=0;         // Counter applied to solve one puzzle.
        public bool       IsChecked=true;   // Algorithm valid

        public UAlgMethod( ){ }
        public UAlgMethod( int pid, int recm, string MethodName, int difficultyLevel, dSolver Method, bool GenLogB=false ){
            this.ID         = pid*1000+(ID0++); //System default order.
            this.recm       = recm;   

			this.Method     = Method;
            this.MethodName = MethodName;
            this.difficultyLevel   = difficultyLevel;     //Level of difficulty
			this.MethodKey  = ID.ToString().PadLeft(7) +difficultyLevel.ToString().PadLeft(2) +MethodName;

            this.GenLogB    = GenLogB;
        }
        public override string ToString(){
			string stMName = $"{MethodName} (dif:{difficultyLevel} cc:{UsedCC})";
            string st = stMName.PadRight(35);
            st += "GeneralLogic:"+GenLogB.ToString();
            return st;
        }
    }
}