using System;
using System.Collections.Generic;
using System.Linq;
using static System.Math;
using static System.Diagnostics.Debug;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace GNPXcore{

    // Trial and error solver independent of GNPX. Prioritizes ease of understanding.


    public class Research_trial_Simple{  
        private List<int>    intBoard;
		private List<sUCell> sBoard = new List<sUCell>();
        
        private int[]   RowF=new int[9], ColF=new int[9], BlkF=new int[9];
        private  List<int>[]  RowPosLst = new List<int>[9];    //Undetermined cells position in row
        private  List<int>[]  RowNumLst = new List<int>[9];    //Undetermined numbers in row

        // ----- Result -----
        private int		SolCode;
        public  string	Result;
        public  int[]	Sol = new int[81];

        private List<int[]>   solList = new();


        private bool devPrintB=false;

        public Research_trial_Simple( List<int> intBoard ){
            if( (intBoard is null) || intBoard.Count!=81 )  return; 

			this.intBoard = intBoard;
            int rcX=0;
            sBoard = intBoard.ConvertAll( n => new sUCell( rcX++, n, 0 ) );

            foreach( var P in sBoard ){
                int freeB9=0;  
                if( P.No==0 ){
                    foreach( var rc in __IEGetCellsConnectedRC(P.rc).Where(p=>sBoard[p].No!=0 ) ){
                        freeB9 |= 1<<(Abs(sBoard[rc].No)-1); //bit representation of  fixed cells
                    }
                    P.FreeB = freeB9 ^ 0x1FF;      //internal expression with 1 right bit shift, and EOR.
                        // WriteLine( P );
                }
            }
			for( int k=0; k<9 ; k++ ){ RowPosLst[k]=new(); RowNumLst[k]=new(); }
			RowF=new int[9]; ColF=new int[9]; BlkF=new int[9];
        }

        public bool TrialAndErrorApp( string TE_fileName="", bool onlyMultipleSolutions=true ){
            // ----- Preparation -----
            for( int k=0; k<9 ; k++ ){ RowPosLst[k].Clear(); RowNumLst[k].Clear(); }
			RowF=new int[9]; ColF=new int[9]; BlkF=new int[9];

            for( int rc=0; rc<81; rc++ ){
                sUCell P = sBoard[rc];
                if( P.No != 0 )  Sol[P.rc] = Abs(P.No);
                else{
                    RowF[rc/9] |= P.FreeB;
                    ColF[rc%9] |= P.FreeB;
                    BlkF[rc.ToBlock()] |= P.FreeB;
                    RowPosLst[rc/9].Add(rc);
                }
            }

            for( int k=0; k<9; k++ ){
                foreach( var p in RowF[k].IEGet_BtoNo() )  RowNumLst[k].Add(p); //Undetermined numbers in row
            }

        // ----- Starting the solver -----       
            {
                solList.Clear();
                Stopwatch sw = new Stopwatch();
                sw.Start();
                Set_RowLine( 0, RowF, ColF, BlkF );
                var elaps = sw.ElapsedMilliseconds;
            }

            if( solList.Count >= 2 ){
                SolCode = -1;
                Result = "There are multiple solutions.";
            }
            else if( solList.Count == 1 ){
                Sol = solList[0];
                Result = "Trial And Error";
            }
            
			if( TE_fileName!=null && TE_fileName!="" ){
				if( !onlyMultipleSolutions || (onlyMultipleSolutions && solList.Count>1) ){
					using( var fpW=new StreamWriter(TE_fileName, append:true, Encoding.UTF8) ){
						fpW.WriteLine( $"\n{DateTime.Now}  {solList.Count} solutions" );
						fpW.WriteLine( $"{string.Join("",intBoard).Replace("0",".")}  puzzle" );

						string unavoidable = __Find_unavoidable(solList);
						fpW.WriteLine( $"{unavoidable}  @:unavoidable cell" );

						int mx=0;
						solList.ForEach( Q => fpW.WriteLine( $"{string.Join("",Q).Replace("-","")}  solution:{++mx:00}") );
					}
				}
			}

            return (SolCode>0);

			string __Find_unavoidable( List<int[]> solList ){
				int[] FreebList = new int[81];
				solList.ForEach( P => { for( int rc=0; rc<81; rc++ ) FreebList[rc] |= (1<<(Abs(P[rc]))); } );
				var Q = FreebList.ToList().ConvertAll(p=> p.BitCount()==1? ".": "@" );			
				return string.Join("",Q);
			}
        }

      
        private bool Set_RowLine( int rowNo, int[] RowF0, int[] ColF0, int[] BlkF0 ){
            // Check_sol( rowNo, RowF0, ColF0, BlkF0 );

            if( rowNo==9 ){   // ... found 
                if( devPrintB ) Check_sol( rowNo, RowF0, ColF0, BlkF0);//, Sol0 );

                SolCode = 1;
                int[] SolCpy = new int[81];
                for( int k=0; k<81; k++ )  SolCpy[k] = Sol[k];
                solList.Add(SolCpy); 
                return true;
            }

            int nc = RowF[rowNo].BitCount();                        //number of blanks in row
            if( nc==0 ){
                bool ret = Set_RowLine( rowNo+1, RowF0, ColF0, BlkF0 );
            }
            else{
                List<int> RowPosLstX = RowPosLst[rowNo];
                List<int> RowNumLstX = RowNumLst[rowNo];

                int[]   ColF1=new int[9], BlkF1=new int[9];
                Permutation0 prmX = new(nc);
                int nxt=9;
                while( prmX.Successor(skip:nxt) ){

                    for( int k=0; k<9 ; k++ ){ ColF1[k]=ColF0[k]; BlkF1[k]=BlkF0[k]; }
                    //Copying blocks(BlkF1) is redundant. But simpler is faster.

                    nxt = nc;    
					
                    for( int k=0; k<nc; k++ ){
                        int rc = RowPosLstX[k], c=rc%9, b=rc.ToBlock();
                        int no = RowNumLstX[ prmX.Index[k] ];
                        int noB = 1<<no;

                        if( (ColF1[c]&noB) == 0 ){ nxt=k; goto L_next_prmX; }
                        if( (BlkF1[b]&noB) == 0 ){ nxt=k; goto L_next_prmX; }
                        ColF1[c] = ColF1[c].DifSet(noB);
                        BlkF1[b] = BlkF1[b].DifSet(noB);  
                        Sol[rc] = -(no+1);
                    }
                    bool ret1 = Set_RowLine( rowNo+1, RowF0, ColF1, BlkF1 );

                 L_next_prmX:
                    continue;
                }
                return false;
            }

            return (rowNo==0 && SolCode>0);
        }




        private int solcc = 0;
        private void Check_sol( int rowNo, int[] RowF0, int[] ColF0, int[] BlkF0 ){
            solcc++;
            if( rowNo <= 7 )  return;
            string st = $"** rowNo:{rowNo} solcc:{solcc}";

         // for( int k=0; k<9; k++ )  st += $"\rfree k:{k}  r:{RowF0[k].ToBSt()}  c:{ColF0[k].ToBSt()}  b:{BlkF0[k].ToBSt()} "; 
            for( int rc=0; rc<81; rc++ ){
                if( rc%9 == 0 )  st += $"\r  {rc/9}: ";
                int s = Sol[rc];
                st += (s>0)? $"  {s}": (s<0)? $" {s}": "  .";
            }
            WriteLine( st );

        }

        private IEnumerable<int> __IEGetCellsConnectedRC( int rc ){ 
            int r=0, c=0;
            for(int kx=0; kx<27; kx++ ){
                switch(kx/9){
                    case 0: r=rc/9; c=kx%9; break; //row 
                    case 1: r=kx%9; c=rc%9; break; //collumn
                    case 2: int b=rc/27*3+(rc%9)/3; r=(b/3)*3+(kx%9)/3; c=(b%3)*3+kx%3; break;//block
                }
                yield return r*9+c;
            }
        }
    }
 


    public class sUCell{ //Basic Cell Class
        public readonly int  rc;    //cell position(0-80)
        public readonly int  r;     //row
        public readonly int  c;     //column
        public readonly int  b;     //block

        public int      No;         //>0:Puzzle  =0:Open  <0:Solution
        public int      FreeB;      //Bit expression of candidate digits


        public sUCell( ){}
        public sUCell( int rc, int No=0, int FreeB=0 ){
            this.rc=rc; this.r=rc/9; this.c=rc%9; this.b=rc/27*3+(rc%9)/3;
            this.No=No; this.FreeB=FreeB;   
        }

        public override string ToString(){
            string st = $" sUCell rc:{rc}[r{r+1}c{c+1}]  no:{No}";
            st +=" FreeB:" + FreeB.ToBitString(9);
            return st;
        }
    }

    static class Functions_for_Research_trial_Simple{
 
        static Functions_for_Research_trial_Simple(){
            for(int n=0; n<512; n++ ) __BC[n] = (n+512).BitCount()-1;           //avoid recursion with "+512"
        }
        static private IEnumerable<int> IEGet_BtoNo( this int noBin, int sz=9 ){
            for(int no=0; no<sz; no++ ){
                if((noBin&(1<<no))>0)  yield return no;
            }
            yield break;
        }

        static public int BitSet( this int X, int n )   => X |= (1<<n);
        static public int BitReset( this int X, int n ) => X &= (1<<n)^0x7FFFFFFF;

        static public int DifSet( this int A, int B )   => (int)(A&(B^0x7FFFFFFF)); 
        static public int DifSet( this uint A, uint B )   => (int)(A&(B^0xFFFFFFFF)); 
        static int[] __BC = new int[512];


        static public int BitCount( this int nF ) => ((uint)nF).BitCount();
        static public int BitCount( this uint nF ){     //by Hacker's Delight
            if( nF < 512 )  return __BC[nF];  //for 9 bits or less, refer to the table. fast.
            uint x = nF;
            x = (x&0x55555555) + ((x>>1)&0x55555555);
            x = (x&0x33333333) + ((x>>2)&0x33333333);
            x = (x&0x0F0F0F0F) + ((x>>4)&0x0F0F0F0F);
            x = (x&0x00FF00FF) + ((x>>8)&0x00FF00FF);
            x = (x&0x0000FFFF) + ((x>>16)&0x0000FFFF);
            return (int)x;
        }

        static private string ToString81s( this UInt128 arg81 ){
            string st="";
            for(int n=0; n<9; n++){
                int w = (int)arg81&0x1FF;
                st += w.ToBitString(9);
                if( n%3 == 2 )  st += " ";       
                if( n<8 ) st += " ";
                arg81 >>= 9;
            }
            return st;
        }
    }

    public class Permutation0{
        protected readonly int N;
        protected readonly int R;
        private int[] Pwrk=null;
        public  int[] Index=null;
        private bool  First;
 
        public Permutation0(int N,int R=-1){
            this.N=N;
            this.R=R;
            if(R<=0 || R>N) this.R=N;
            if(N>0){
                Pwrk = Enumerable.Range(0,N).ToArray();
                Index = Enumerable.Range(0,this.R).ToArray();
            }
            First=true;
        }
        public bool Successor( int skip=-1){
            if(N<=0) return false;
            if(First || Pwrk==null){ First=false; return (Pwrk!=null); }
            int r = (skip>=0)? skip: R-1;
            r = Min(r,R-1);
            
            do{
                if(r<0)  break;
                int A=Pwrk[r];
        
            L_1: 
                if(A>=N-1){ r--; continue; }
                A++;
                for(int nx=0; nx<r; nx++ ){ if(Pwrk[nx]==A) goto L_1; }  
                Pwrk[r]=A;
                if(r<N-1){
                    if(N<=64){
                        ulong bp=0;
                        for(int k=0; k<=r; k++) bp |= (1u<<Pwrk[k]);
                        r++;
                        for(int n=0; n<N; n++ ){
                            if((bp&(1u<<n))==0){
                                Pwrk[r++]=n;
                                if(r>=N) break;
                            }
                        }
                    }
                    else{
                        int[] wx = Enumerable.Range(0,N).ToArray();
                        for(int k=0; k<=r; k++) wx[Pwrk[k]]=-1;

                        int s=0;
                        for(int k=r+1; k<N; k++){
                            for(; s<N; s++){
                                if(wx[s]<0) continue;
                                Pwrk[k]=wx[s++];
                                break;
                            }
                        }
                    }
                }
                for(int k=0; k<R; ++k) Index[k]=Pwrk[k];
                return true;
            }while(true);
            return false;
        }

        public int ToBitExpression( ){
            int bitR = 0;
            foreach( var x in Index ) bitR |= (1<<x);
            return bitR;
        }

        public override string ToString(){
            string st=""; Array.ForEach(Index, p=> st+=(" "+p));
            st += "  ";   Array.ForEach(Pwrk, p=> st+=(" "+p));
            return st;
        }
    }
}