﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Globalization;

using static System.Math;
using static System.Diagnostics.Debug;

using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;

using Microsoft.Win32;
using System.Runtime.InteropServices;

using System.Diagnostics;
using System.Threading;
using System.Windows.Threading;
using System.Threading.Tasks;

using DColor = System.Drawing.Color;

using GIDOO_space;
using System.Text;







namespace GNPXcore{
    using pRes=Properties.Resources;
    using sysWin=System.Windows;

    public partial class NuPz_Win: sysWin.Window{
        static public bool    eventSuspend=false;
        [DllImport("USER32.dll",CallingConvention=CallingConvention.StdCall)]
        static private extern void SetCursorPos(int X,int Y); //Move the mouse cursor to Control

        private sysWin.Point    _WinPosMemo;


    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==
        public  GNPX_App        GNPX_000;

        public SDK_Ctrl         pSDKCntrl => GNPX_000.SDKCntrl;
        private GNPZ_Engin      pGNPX_Eng => GNPX_000.pGNPX_Eng;   
        private GNPX_AnalyzerMan pAnMan   => pGNPX_Eng.AnMan;

        private UPuzzleMan      pPZLMan    => pGNPX_Eng.PZLMan;
        private UPuzzle         pPZL      => pPZLMan.PZL;      // current board
        private int             stageNo => (pPZLMan is null)? 0: pPZLMan.stageNo;

    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==

    // ----- display-related definitions -----
        public  GNPZ_Graphics   SDKGrp; //board surface display bitmap

        private List<RadioButton> patSelLst;
        private List<RadioButton> rdbVideoCameraLst;
      //private List<Control>  _contorols;

        public  CultureInfo     culture => pRes.Culture;

        private int             WOpacityCC=0;



    // ----- Extend -----
        private DevelopWin      devWin;
        private ExtendResultWin ExtResultWin;

    

    #region Application start/end
        public NuPz_Win(){          
            // GNPX_unitTest( testB:true );

			//GNPX_tracer( "\n", "NuPz_Win start" );

            try{
                GNPX_App.pixelsPerDip = VisualTreeHelper.GetDpi(this).PixelsPerDip;

                GNPX_000  = new GNPX_App(this);
                  //GNPX_Develop_prepare();

                SDKGrp = new GNPZ_Graphics(GNPX_000);

                InitializeComponent();     

                lblCurrentndifficultyLevel.Visibility=Visibility.Hidden;
                lblShortMessage.Visibility = Visibility.Hidden;
                LblGeneralLogic.Visibility = Visibility.Hidden;
                GNPXGNPX.Content = G.GNPXvX;
      
                LblGeneralLogic.Visibility = Visibility.Visible;
                devWin = new DevelopWin(this);

                GNPXGNPX.Content = G.GNPXvX;

                cmbLanguageLst.ItemsSource = GNPX_000.LanguageLst;  
           
                //RadioButton Controls Collection
                var rdbLst = GNPZExtender.GetControlsCollection<RadioButton>(this);
                patSelLst  = rdbLst.FindAll(p=>p.Name.Contains("patSel"));
                rdbVideoCameraLst = rdbLst.FindAll(p=>p.Name.Contains("rdbCam"));

                 //_contorols = GNPZExtender.GetControlsCollection<Control>(this);

              #region Timer
                AnalyzerLap = new Stopwatch();


                cleaningUpTimer = new DispatcherTimer(DispatcherPriority.Normal);
                cleaningUpTimer.Interval = TimeSpan.FromMilliseconds(500);
                cleaningUpTimer.Tick += new EventHandler(cleaningUpTimer_Tick);

                timerShortMessage = new DispatcherTimer(DispatcherPriority.Normal);
                timerShortMessage.Interval = TimeSpan.FromMilliseconds(50);
                timerShortMessage.Tick += new EventHandler(timerShortMessage_Tick);

                startingTimer = new DispatcherTimer( DispatcherPriority.Normal, this.Dispatcher );
                startingTimer.Interval = TimeSpan.FromMilliseconds(70);
                startingTimer.Tick += new EventHandler(startingTimer_Tick);
                this.Opacity=0.0;
                startingTimer.Start();

                endingTimer = new DispatcherTimer( DispatcherPriority.Normal, this.Dispatcher );
                endingTimer.Interval = TimeSpan.FromMilliseconds(70);
                endingTimer.Tick += new EventHandler(endingTimer_Tick);

                displayTimer = new DispatcherTimer( DispatcherPriority.Normal, this.Dispatcher );
                displayTimer.Interval = TimeSpan.FromMilliseconds(100);//50
                displayTimer.Tick += new EventHandler(displayTimer_Tick);

                bruMoveTimer = new DispatcherTimer( DispatcherPriority.Normal, this.Dispatcher );
                bruMoveTimer.Interval = TimeSpan.FromMilliseconds(20);
                bruMoveTimer.Tick += new EventHandler(bruMoveTimer_Tick);

                #endregion Timer

                bmpGZero = new RenderTargetBitmap((int)PB_GBoard.Width,(int)PB_GBoard.Height, 96,96, PixelFormats.Default);
                SDKGrp.GBoardPaint( bmpGZero, (new UPuzzle()).BOARD, "tabACreate" );
                PB_GBoard.Source = bmpGZero;    //◆Initial setting

                lblProcessorCount.Content = "ProcessorCount:"+Environment.ProcessorCount;

              #region Copyright
                string endl = "\r";
                string st = "【著作権】" + endl;
                st += "本ソフトウエアと付属文書に関する著作権は、作者GNPX に帰属します。" + endl;
                st += "本ソフトウエアは著作権法及び国際著作権条約により保護されています。" + endl;
                st += "使用ユーザは本ソフトウエアに付された権利表示を除去、改変してはいけません" + endl + endl;

                st += "【配布】" + endl;
                st += "インターネット上での二次配布、紹介等は事前の承諾なしで行ってかまいません。";
                st += "バージョンアップした場合等には、情報の更新をお願いします。" + endl;
                st += "雑誌・書籍等に収録・頒布する場合には、事前に作者の承諾が必要です。" + endl + endl;
                   
                st += "【禁止事項】" + endl;
                st += "以下のことは禁止します。" + endl;
                st += "・オリジナル以外の形で、他の人に配布すること" + endl;
                st += "・第三者に対して本ソフトウエアを販売すること" + endl;
                st += "・販売を目的とした宣伝・営業・複製を行うこと" + endl;
                st += "・第三者に対して本ソフトウエアの使用権を譲渡・再承諾すること" + endl;
                st += "・本ソフトウエアに対してリバースエンジニアリングを行うこと" + endl;
                st += "・本承諾書、付属文書、本ソフトウエアの一部または全部を改変・除去すること" + endl + endl;

                st += "【免責事項】" + endl;
                st += "作者は、本ソフトウエアの使用または使用不能から生じるコンピュータの故障、情報の喪失、";
                st += "その他あらゆる直接的及び間接的被害に対して一切の責任を負いません。" + endl;
                CopyrightJP=st;

                st="===== CopyrightDisclaimer =====" + endl;
                st += "Copyright" + endl;
                st += "The copyright on this software and attached document belongs to the author GNPX" + endl;
                st += "This software is protected by copyright law and international copyright treaty." + endl;
                st += "Users should not remove or alter the rights indication attached to this software." + endl + endl;

                st += "distribution" + endl;
                st += "Secondary distribution on the Internet, introduction etc. can be done without prior consent.";
                st += "Please update the information when upgrading etc etc." + endl;
                st += "In the case of recording / distributing in magazines · books, etc., consent of the author is necessary beforehand." + endl + endl;
                   
                st += "Prohibited matter" + endl;
                st += "The following things are forbidden." + endl;
                st += "Distribute it to other people in forms other than the original." + endl;
                st += "Selling this software to a third party." + endl;
                st += "Promotion, sales and reproduction for sale." + endl;
                st += "Transfer and re-accept the right to use this software to a third party." + endl;
                st += "Modification / removal of this consent form and attached document" + endl + endl;

                st += "Disclaimer" + endl;
                st += "The author assumes no responsibility for damage to computers, loss of information or any other direct or indirect damage resulting from the use or inability of the Software." + endl;
                CopyrightEN=st;
                txtCopyrightDisclaimer.Text = CopyrightEN;
              #endregion Copyright

                tabCtrlMode.Focus();
                PB_GBoard.Focus();    
				
				//GNPX_tracer( "", "NuPz_Win end" );
            }
            catch( Exception ex ){ WriteLine( $"{ex.Message}\r{ex.StackTrace}"); }

        }
        private void Window_Loaded( object sender, RoutedEventArgs e ){

            _Display_GB_GBoard( );       //board setting
            _SetBitmap_PB_pattern();     //Pattern setting

            eventSuspend = true;

                Lbl_onAnalyzing.Content    = "";
                Lbl_onAnalyzingM.Content   = "";
                Lbl_onAnalyzingTS.Content  = "";
                Lbl_onAnalyzingTSM.Content = "";
                elpOnWork.Visibility = Visibility.Hidden;
            
                //===== solution list setting =====           
                GMethod00A.ItemsSource = GNPX_000.ReadFile_MethodList_AnalysisConditions();
                GMethod00A.IsEnabled = true;

				RandomSeed.Text			   = GNPX_App.GMthdOption["RandomSeed"].ToString();
                MSlvrMaxLevel.Value        = (int)GNPX_App.GMthdOption["MSlvrMaxLevel"];
                MSlvrMaxAlgorithm.Value    = (int)GNPX_App.GMthdOption["MSlvrMaxAlgorithm"];
                MSlvrMaxAllAlgorithm.Value = (int)GNPX_App.GMthdOption["MSlvrMaxAllAlgorithm"];
                MSlvrMaxTime.Value         = (int)GNPX_App.GMthdOption["MSlvrMaxTime"];
                chkPreferSimpleLinks.IsChecked = ((int)GNPX_App.GMthdOption["PreferSimpleLinks"]>0);
                chkUse_eALS.IsChecked      = ((int)GNPX_App.GMthdOption["Use_eALS"]>0);

                NiceLoopMax.Value         = (int)GNPX_App.GMthdOption["NiceLoopMax"];
                ALSSizeMax.Value          = (int)GNPX_App.GMthdOption["ALSSizeMax"];
                ALSChainSizeMax.Value     = (int)GNPX_App.GMthdOption["ALSChainSizeMax"];

                method_NLCell.IsChecked   = (bool)GNPX_App.GMthdOption["Cell"];
                method_NLAIC.IsChecked    = (bool)GNPX_App.GMthdOption["AIC"];
                method_NLALS.IsChecked    = (bool)GNPX_App.GMthdOption["ALS"];
                method_NLALSXZ.IsChecked  = (bool)GNPX_App.GMthdOption["ALSXZ"];
                method_NLAnLS.IsChecked   = (bool)GNPX_App.GMthdOption["AnLS"];
				method_NLeALS.IsChecked   = (bool)GNPX_App.GMthdOption["eALS"];

				bool ALSb = (bool)method_NLALS.IsChecked;
					method_NLALSXZ.IsEnabled = ALSb;
					method_NLAnLS.IsEnabled = ALSb;
					method_NLeALS.IsEnabled = ALSb;
				Brush br = ALSb? Brushes.White: Brushes.LightPink; 
					method_NLALSXZ.Foreground = br;
					method_NLAnLS.Foreground = br;
					method_NLeALS.Foreground = br;

                chkLinkExtension.IsChecked = (bool)GNPX_App.GMthdOption["UCellLinkExt"];
                chkDebugSolCheckMode.IsChecked = (bool)GNPX_App.GMthdOption["DebugSolCheckMode"];
#if !DEBUG
                chkDebugSolCheckMode.IsChecked = false;
                chkDebugSolCheckMode.Visibility = Visibility.Hidden;
#endif

                int Solver_MaxLevel = pAnMan.SolverLst0.Max( p=>p.difficultyLevel );
                MSlvrMaxLevel.MaxValue = Solver_MaxLevel;
                MSlvrMaxLevel.ToolTip = $"max:{Solver_MaxLevel}";

			    string st=(string)GNPX_App.GMthdOption["ForceLx"];
			    switch(st){
				    case "ForceL1": ForceL1.IsChecked=true; break;
				    case "ForceL2": ForceL2.IsChecked=true; break;
				    case "ForceL3": ForceL3.IsChecked=true; break;
			    }
                ShowProofMultiPaths.IsChecked  = (bool)GNPX_App.GMthdOption["ShowProofMultiPaths"];

        eventSuspend = false;
            //*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
      //  #if !DEBUG
			GNPX_App.GMthdOption["GeneralLogic_on"] = false;   // Releace => GeneralLogic Off
      //  #endif
            //*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
// GNPX_tracer( "", "Window_Loaded 200" ); // #####
            GeneralLogicOnChbx.IsChecked = (bool)GNPX_App.GMthdOption["GeneralLogic_on"];
            int GLMaxSize = (int)GNPX_App.GMthdOption["GenLogMaxSize"];
            if( GLMaxSize>0 && GLMaxSize<=(int)GenLogMaxSize.MaxValue ) GenLogMaxSize.Value=GLMaxSize;

            int GLMaxRank = (int)GNPX_App.GMthdOption["GenLogMaxRank"];
            if( GLMaxRank>=0 && GLMaxRank<=(int)GenLogMaxRank.MaxValue ) GenLogMaxRank.Value=GLMaxRank;

            WOpacityCC = 0;
            startingTimer.Start();

            _WinPosMemo = new sysWin.Point(this.Left,this.Top+this.Height);
            
            { //Move the mouse cursor to Button:btnOpenPuzzleFile                 
                var btnQ=btnOpenPuzzleFile;                    
                var ptM=new Point(btnQ.Margin.Left+btnQ.Width/2,btnQ.Margin.Top+btnQ.Height/2);//Center coordinates
                var pt = grdFileIO.PointToScreen(ptM);  //Grid relative coordinates to screen coordinates.
                SetCursorPos((int)pt.X,(int)pt.Y);      //Move the mouse cursor
            }

            Develp_Reset_Click(sender,e);
            sNoAssist = (bool)chbSetAnswer.IsChecked;
            chbDigitsColoring.IsEnabled = sNoAssist;
            grd_develop_new_Algorithm.Visibility = (sNoAssist && (bool)chbDigitsColoring.IsChecked) ? Visibility.Visible : Visibility.Hidden;

// GNPX_tracer( "", "Window_Loaded end" ); // #####
        }

        private void Window_Unloaded( object sender, RoutedEventArgs e ){
            Environment.Exit(0);
        }
    #endregion Application start/end 


        private void  GNPXGNPX_MouseDoubleClick( object sender, MouseButtonEventArgs e ){
            if(devWin==null) devWin=new DevelopWin(this);
            devWin.Show();
            devWin.Set_dev_GBoard(pPZL.BOARD);
        }

		private void btnEmergency_MouseDoubleClick(object sender, MouseButtonEventArgs e) {
			btnEmergency.Background = Brushes.Red;
			btnEmergency.Foreground = Brushes.White;

			pGNPX_Eng.Emergency_FilePut();
        }

	}
}