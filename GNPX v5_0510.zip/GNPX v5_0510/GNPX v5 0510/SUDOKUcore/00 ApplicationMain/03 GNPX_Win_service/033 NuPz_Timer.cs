﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

using static System.Math;
using static System.Diagnostics.Debug;

using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using static System.Diagnostics.Debug;
using System.Globalization;

using System.Threading;
using System.Windows.Threading;
using System.Diagnostics;

using GIDOO_space;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace GNPXcore{
    using sysWin=System.Windows;
    using pRes=Properties.Resources;

    //*==*==*==*==*==*==*==*==*==*==*==*==*
    // Change the expression of Sudoku.
    //*==*==*==*==*==*==*==*==*==*==*==*==*

    public partial class NuPz_Win{  //Puzzle Transform

        // ----- timer -----
        private DispatcherTimer cleaningUpTimer;
        private DispatcherTimer startingTimer;
        private DispatcherTimer endingTimer;
        private DispatcherTimer displayTimer;   
        private DispatcherTimer bruMoveTimer;
        private DispatcherTimer timerShortMessage;
        private RenderTargetBitmap bmpGZero;
        
		private Stopwatch       AnalyzerLap;

        private string          AnalyzerLapElaped{
            get{
                TimeSpan ts = AnalyzerLap.Elapsed;
                string st = "";
                if( ts.TotalSeconds>1.0 ) st += ts.TotalSeconds.ToString("0.0") + " sec";
                else                      st += ts.TotalMilliseconds.ToString("0.0") + " msec";
                return st;
            }
        }
	    #region Start/end Timer    
        private void appExit_Click( object sender, RoutedEventArgs e ){
            GNPX_000.OutPut_MethodList();

            WOpacityCC=0;
            endingTimer.IsEnabled = true;
            endingTimer.Start();
        }

        private void cleaningUpTimer_Tick(object sender, EventArgs e){
            if( displayTimer.IsEnabled )  return;

            elpOnWork.Visibility = Visibility.Hidden;
            cleaningUpTimer.Stop();
        }

        private void startingTimer_Tick( object sender, EventArgs e){
            WOpacityCC++;
            if( WOpacityCC >= 40 ){ this.Opacity=1.0; startingTimer.Stop(); }
            else{
				this.Opacity = WOpacityCC/40.0;
				if( devWin!=null ) devWin.Opacity = WOpacityCC/40.0;
			}
        }
        private void endingTimer_Tick( object sender, EventArgs e){
            if( (++WOpacityCC)>20 )  Environment.Exit(0);   //Application.Exit();
            double dt = 1.0-WOpacityCC/20.0;
            this.Opacity = dt*dt;
			if( devWin!=null ) devWin.Opacity = dt*dt;
        }
        
        private void __bruMoveSub(){ 
            Thickness X=PB_GBoard.Margin;
            PB_GBoard.Margin=new Thickness(X.Left+2,X.Top+2,X.Right,X.Bottom);
            bruMoveTimer.Start();
        }      
        private void bruMoveTimer_Tick( object sender, EventArgs e){
            Thickness X=PB_GBoard.Margin;   //◆
            PB_GBoard.Margin=new Thickness(X.Left-2,X.Top-2,X.Right,X.Bottom);
            bruMoveTimer.Stop();
        }       
    #endregion TimerEvent


    #region ShortMessage
	public void shortMessage( string st, sysWin.Point pt, Color cr, int tm ){
            lblShortMessage.Content = st;
            lblShortMessage.Foreground = new SolidColorBrush(Colors.White);
            lblShortMessage.Background = new SolidColorBrush(cr);
            lblShortMessage.Margin = new Thickness(pt.X,pt.Y,0,0);

            if( tm==9999 ) timerShortMessage.Interval = TimeSpan.FromSeconds(5);
            else           timerShortMessage.Interval = TimeSpan.FromMilliseconds(tm);            
            timerShortMessage.Start();
            lblShortMessage.Visibility = Visibility.Visible;
        }
        private void timerShortMessage_Tick( object sender, EventArgs e ){
            lblShortMessage.Visibility = Visibility.Hidden;
            timerShortMessage.Stop();
        }
    #endregion ShortMessage

    }
}