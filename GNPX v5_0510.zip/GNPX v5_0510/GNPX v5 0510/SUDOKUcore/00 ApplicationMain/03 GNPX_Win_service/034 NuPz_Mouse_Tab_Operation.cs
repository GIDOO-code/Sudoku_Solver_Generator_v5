﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

using static System.Math;
using static System.Diagnostics.Debug;

using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using static System.Diagnostics.Debug;
using System.Globalization;

using System.Threading;
using System.Windows.Threading;
using System.Diagnostics;

using GIDOO_space;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace GNPXcore{
    using sysWin=System.Windows;
    using pRes=Properties.Resources;

    //*==*==*==*==*==*==*==*==*==*==*==*==*
    // Change the expression of Sudoku.
    //*==*==*==*==*==*==*==*==*==*==*==*==*

    public partial class NuPz_Win{  //Puzzle Transform

    #region Location
		private void GNPXwin_LocationChanged( object sender,EventArgs e ){ //Synchronously move open window
            foreach( sysWin.Window w in Application.Current.Windows )  __GNPXwin_LocationChanged(w);
            _WinPosMemo = new sysWin.Point(this.Left,this.Top);
		}
		private void __GNPXwin_LocationChanged( sysWin.Window w ){
            if( w==null || w.Owner==this || w==this )  return;
            w.Left = this.Left-_WinPosMemo.X+w.Left;
            w.Top  = this.Top -_WinPosMemo.Y+w.Top ;
            w.Topmost=true;
        }	
    #endregion Location


        private void Window_MouseDown( object sender, MouseButtonEventArgs e ){
            if(e.Inner(PB_GBoard))    return; //◆
            if(e.Inner(tabCtrlMode))  return;
            this.DragMove();
        }
        

    #region　operation mode
        private string preGSmode="";
        private void tabCtrlMode_SelectionChanged( object sender, SelectionChangedEventArgs e ){
            if( (TabControl)sender!=tabCtrlMode ) return;
            CopiedHP.Visibility = Visibility.Hidden;
            Clipboard.Clear();
            HP_address.Text = "";
            TabItem tb=tabCtrlMode.SelectedItem as TabItem;
            if(tb==null)  return;
            if( tb.Name.Substring(0,4)!="tabA" )  return;
            GNPX_000.GSmode = (string)tb.Name;    //Tab Name -> State mode
                //WriteLine( $"tabCtrlMode_SelectionChanged TabItem:{GNPX_000.GSmode}" );

            //if( preGSmode=="tabACreate" ){ btnSaveePuzzle_Click( sender, e ); preGSmode=""; }

            switch(GNPX_000.GSmode){
                case "tabASolve": sNoAssist = (bool)chbShowCandidate.IsChecked; break;
                case "tabACreate":
                    TabItem tb2=tabAutoManual.SelectedItem as TabItem;
                    if( tb2==null )  return ;
                    if( (string)tb2.Name=="tabBAuto" )  sNoAssist=false;
                    else sNoAssist = (bool)chbShowNoUsedDigits.IsChecked;
                    gridExhaustiveSearch.Visibility=
                        (int.Parse(GenLStyp.Text)==2)? Visibility.Visible: Visibility.Hidden;                   

                  //  preGSmode = "tabACreate";
                    break;

                case "tabAOption":
                    bool sAssist=true;
                    chbSetAnswer.IsChecked=sAssist;
                    sNoAssist=sAssist;
                    break;
        
                default: sNoAssist=false; break;
            }
            _Display_GB_GBoard();   
            //tabSolver_SelectionChanged(sender,e);
        }      

        private string preTabName="";

        private void tabSolver_SelectionChanged( object sender, SelectionChangedEventArgs e ){
            TabItem tabItm = tabSolver.SelectedItem as TabItem;
            if( tabItm!=null ){
                SDK_Ctrl.MltAnsSearch = (tabItm.Name=="tabBMultiSolve");  
                
                if( preTabName=="tabBMethod" )  GNPX_000.OutPut_MethodList(); //*****
                preTabName = tabItm.Name;
            }
        }
        #endregion operation mode

    }
}