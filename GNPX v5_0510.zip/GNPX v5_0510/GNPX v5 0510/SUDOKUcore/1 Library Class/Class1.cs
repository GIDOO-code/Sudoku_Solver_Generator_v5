﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GNPXcore._1_Library_Class {
	internal class Class1 {
	}
}
