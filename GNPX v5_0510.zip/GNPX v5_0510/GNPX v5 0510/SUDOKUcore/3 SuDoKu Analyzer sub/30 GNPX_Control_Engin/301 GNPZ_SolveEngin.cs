using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Threading;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Media;

using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.Reflection;
using System.Windows.Documents;
using System.Reflection.Emit;
using SUDOKUcore;
using System.Windows.Interop;
using System.Reflection.Metadata;
using System.Security.Cryptography;

namespace GNPXcore{
    public partial class GNPZ_Engin{                        // This class-object is unique in the system.
        static public bool       SolInfoB;    
        static public int        eng_retCode;                   // result
        static public UAlgMethod AnalyzingMethod;
		static public string     AdditionalMessage;
        static public TimeSpan   SdkExecTime;  
        static public bool       SolverBusy=false;
		static public UAlgMethod method_maxDiffcult0;

//		static public UPuzzleMan PZLMan0;
                       
        private bool             __ChkPrint__ = false; // true; // for debug

        public  GNPX_App         pGNP00;                    // main control     
        public  GNPX_AnalyzerMan AnMan;                     // analyzer(methods)
        public  CancellationToken ct;
		public  Research_trial   RTrial;

        //    { get; set; } ... Techniques used for debugging.
        //                      Find out where unexpected assignments are made.
        //
      //public  UPuzzle          PZL_Initial{ get; set; }
      //public  UPuzzleMan       PZLMan{ get; set; }         // property to find out where set is executed

        public  UPuzzle          PZL_Initial;
        public  UPuzzleMan       PZLMan;

        public UPuzzle           pPZL{    get=>PZLMan.PZL; set=>PZLMan.PZL=value; } // Puzzle to analyze
        public List<UCell>       pBOARD{  get=>pPZL.BOARD; }

        public  int              stageNo100 = 0; 
        public  int              Add_stageNo() => stageNo100 +=100;    
        private int              stageNo{ get  => PZLMan.stageNo; }
        public  int              stageNoP{ get => stageNo100+PZLMan.stageNo; }


         

        public  List<UPuzzle>    child_PZLs  => PZLMan.child_PZLs;
        private Random rnd = new Random();

        private List<UMthdChked> SolverLst2{ get{ return pGNP00.SolverLst2; } }  // List of algorithms to be applied.
        private List<UAlgMethod> MethodLst_Run = new List<UAlgMethod>();          // List of successful algorithms

        
        public GNPZ_Engin( GNPX_App pGNP00 ){           //Execute once at GNPX startup.
            this.PZLMan = new UPuzzleMan();
            this.pGNP00 = pGNP00;
            AnMan = new GNPX_AnalyzerMan(this);
			RTrial = new(AnMan);
        }

      #region Puzzle management
        public void Clear_0(){
            pPZL.ToInitial( ); // Clear all.
            AnMan.Update_CellsState( pPZL.BOARD, setAllCandidates:true );
        }
        public bool IsSolved() => pBOARD.All(p=> p.No!=0);
        // Set_NewPuzzle : Set the analysis Puzzle to the engine -> PZL_Initial.

		public (bool,string) IsSudokuPuzzle(){
			List<int>  intBoard = pBOARD.ConvertAll(P=>Abs(P.No));
			RTrial = new Research_trial( AnMan );
			RTrial.Preparer_Research_trial( intBoard, filePutB:true );
			bool ret = RTrial.TrialAndErrorApp( );
			return (ret,RTrial.Result);
		}


        public void Set_NewPuzzle( UPuzzle aPZL ){   
            this.PZL_Initial = aPZL;

            UPuzzle pGP000 = aPZL.Copy();
            this.PZLMan = new UPuzzleMan( pGP000, this );                // Create the UPuzzleMan for Analize.
            PZLMan.selectedIX = -1;
            this.PZLMan.stageNo = 0;                                     // set stageNo=0.
            this.Add_stageNo();
            this.PZLMan.PZLManPre = null;
        }

        public void Set_selectedChild( int selX ){
            int cnt = PZLMan.child_PZLs.Count;
            if( selX<0  || cnt<=0 || selX>=cnt ) return;
            pPZL = PZLMan.child_PZLs[selX];
            PZLMan.PZL = pPZL;                            //Set the chosen GP.
            PZLMan.selectedIX = selX;
        }

        public bool Set_NextStage( int _stageNo=-1 ){      // update the state and create the next stage.
            if( AnMan is null ) return false;
            UPuzzle tPZL = null;
            if( _stageNo == 0 )  PZLMan.stageNo = 0;

            if( PZLMan.stageNo == 0 ){
                tPZL = PZL_Initial;
                if( tPZL is null ) return false;
      
                AnMan.Update_CellsState( tPZL.BOARD, setAllCandidates:true );
				bool retCode =  DebugSolCheck_Set( );
				if( !retCode )  return  false;	// *** false : Multiple solutions ***
            }
            else{
                int selectedIX = PZLMan.selectedIX;
                if( selectedIX < 0 )  return false; 
                tPZL = PZLMan.child_PZLs[selectedIX]; 
            }
            
            if( tPZL.BOARD.All(p=>p.No!=0) )  return false; //solved

            UPuzzleMan tPZLManNext = new UPuzzleMan();

         // PZLMan.GPManNxt        = tPZLManNext; //on hold. need?
            tPZLManNext.PZLManPre  = PZLMan;
            tPZLManNext.PZL        = tPZL.Copy();
            tPZLManNext.stageNo    = PZLMan.stageNo+1;

                    //  tPZLManNext.UPuzzleMan_stack_history(tPZLManNext,"Before running PExecute_Fix_Eliminate ----");
            var (codeX,_) = AnMan.Execute_Fix_Eliminate( tPZLManNext.PZL.BOARD );
                // codeX  0:Complete. Go to next stage.  1:Solved.   -1:Error. Conditions are broken.
                    //  tPZLManNext.UPuzzleMan_stack_history(tPZLManNext,"After running PExecute_Fix_Eliminate +++++");
            if( codeX<0 ){  eng_retCode = -998; return false; }

            PZLMan = tPZLManNext;
            PZLMan.child_PZLs.Clear();
            return true;            //check_pGP(aPZL,"Set_NextStage");   
        }

        public bool Restore_PreStage( ){
            if( PZLMan.PZLManPre is null )  return false;     
            this.Add_stageNo();     // for updating the analysis state.
            PZLMan = PZLMan.PZLManPre;
            return true;
        }

/*  // on hold. need?
        public bool Restore_NxtStage( ){
            if( PZLMan.GPManNxt is null )  return false;
            PZLMan = PZLMan.GPManNxt;
            return true;
        }
*/
        public void ReturnToInitial(){
            if( PZL_Initial is null )  PZL_Initial = pPZL;
            this.PZLMan = new UPuzzleMan( PZL_Initial, this );
            
            this.pPZL = PZL_Initial.Copy();
            this.PZLMan.stageNo = 0;
            this.Add_stageNo();
            this.PZLMan.PZL.ToInitial( ); //to initial stage
        }
      #endregion Puzzle management


      #region Methods_for_Solving functions
        // Listing of analysis methods
        public int Set_Methods_for_Solving( bool AllMthd=false, bool GenLogUse=true ){ 

            MethodLst_Run.Clear(); 
            foreach( var S in SolverLst2 ){
                if( !AllMthd && !S.IsChecked )  continue;
                if( S.Name==" GeneralLogic" && !GenLogUse )  continue;
                var Sobj = AnMan.SolverLst0.Find(P=>P.MethodName==S.Name); // List solver-object by name
                MethodLst_Run.Add(Sobj);    // List of algorithms to be applied.
            }
#if DEBUG        
            WriteLine( $"===== Set_Methods_for_Solving  stageNoP:{stageNoP}  MethodLst_Run.Count:{MethodLst_Run.Count}" );  // Find out how it's used       
            var duplicates = SolverLst2.GroupBy(x=>x.Name).Where(g=>g.Count()>1).Select(x=>x.Key).ToList();
            if( duplicates.Count>0 )  WriteLine($"  $$$ System Error Duplicates => {string.Join(",",duplicates)}" );

 #endif           
        return MethodLst_Run.Count;
        }
        public Research_trial Set_Methods_for_Solving_TaE( ){ 
            MethodLst_Run.Clear(); 

            var TryApp = new Research_trial(AnMan);
            var funcTRE = new UAlgMethod( 1, 9, "Research_Trial", 1, TryApp.TrialAndErrorApp );
            MethodLst_Run.Add( funcTRE );                
            return TryApp;
        }

        public void MethodLst_Run_Reset(){
            Add_stageNo();

            MethodLst_Run.ForEach(P=>P.UsedCC=0);
			GNPZ_Engin.method_maxDiffcult0 = null;
            var Q = PZLMan.PZLManPre;
            while( Q != null ){ PZLMan=Q; Q=Q.PZLManPre; /*Thread.Sleep(1);*/ }
        } 

        public string DGViewMethodCounterToString(){
            var Q = MethodLst_Run.Where(p=>p.UsedCC>0).ToList();
            return Q.Aggregate("",(a,q) => a+$" {q.MethodName}[{q.UsedCC}]" );
        }

        public void AnalyzerCounterReset(){ MethodLst_Run.ForEach(P=>P.UsedCC=0); } //Clear the algorithm counter. 

        public int  Get_difficultyLevel( out string puzzleMessage ){
            int DifL=0;
            puzzleMessage="";
            if( MethodLst_Run.Any(P=>(P.UsedCC>0) )){
                DifL = MethodLst_Run.Where(P=>P.UsedCC>0).Max(P=>P.difficultyLevel);
                var R = MethodLst_Run.FindLast(Q=>(Q.UsedCC>0)&&(Q.difficultyLevel==DifL));
                puzzleMessage = (R!=null)? R.MethodName: "";
            }
            return DifL;
        }
      #endregion Methods_for_Solving functions


      #region Analyzer
        // simply solve puzzles
        public void sudoku_Solver_Simple( CancellationToken ct ){
            try{
                GNPX_App.GMthdOption["Canceled"] = "";
                this.ct = ct;
                eng_retCode=0;
                // WriteLine( "--------------- sudoku_Solver_Simple ---------------" );

				// ---------- Update_CellsState ----------
                AnMan.Update_CellsState( pBOARD, setAllCandidates:true );  // allFlag:true : set all candidates
                Stopwatch AnalyzerLap = new Stopwatch();
                AnalyzerLap.Start();

				// ----------  Set the puzzle/phase in the engine ----------
				Set_NewPuzzle( pPZL );        

				// ---------- Solve ----------
                UPuzzleMan GPManNext=null;
                while(true){
                    if( ct.IsCancellationRequested ){ ct.ThrowIfCancellationRequested(); return; }

					// ----- Check the elements to be confirmed -----
                    if( PZLMan.stageNo > 0 ){
                        var (codeX,_) = AnMan.Execute_Fix_Eliminate( pPZL.BOARD ); 
                        if( codeX<0 ){  eng_retCode=-998; return; } // codeX=-1:Error. Conditions are broken.
                        if( codeX==1 )  break;						// codeX=1 : step solved
						// codeX=0 : Complete. Go to next stage.
                    }

                    // ----- Apply the algorithm
                    var (ret,ret2) = sudoku_Solver_SingleStage( ct, false );  // <-- 1-step solver
                    if( !ret ){ eng_retCode=-999; break; }

                    SdkExecTime = AnalyzerLap.Elapsed;
                    if( eng_retCode<0 )  return;
                    PZLMan.stageNo++;
                }
                AnalyzerLap.Stop();    

                var (_,nP,nZ,nM) = AnMan.Aggregate_CellsPZM(pBOARD);
                eng_retCode = nZ;
            }
            catch( OperationCanceledException ){}
            catch( Exception e ){
                WriteLine( e.Message+"\r"+e.StackTrace );
                using(var fpW=new StreamWriter("Exception_201_0.txt",true,Encoding.UTF8)){
                    fpW.WriteLine($"---{DateTime.Now} {e.Message} \r{e.StackTrace}");
                }
            }
        }
       
        // Solve up
        public void sudoku_Solver_Complete( CancellationToken ct ){
            try{
                this.ct = ct;
                eng_retCode =0;

                Stopwatch AnalyzerLap = new Stopwatch();
                AnalyzerLap.Start();    

                UPuzzleMan GPManNext=null;
                PZLMan.stageNo = 0;
                while(true){
                    if( ct.IsCancellationRequested ){ ct.ThrowIfCancellationRequested(); return; }

                    bool retB = Set_NextStage(PZLMan.stageNo);
                    if( !retB )  return;                    // go to the next stage

                    // ================================================
                    var (ret,ret2) = sudoku_Solver_SingleStage( ct, false ); // <-- 1-step solver
                    if( !ret ){ eng_retCode=-999; break; }
                    // -------------------------------------------------

                    SdkExecTime = AnalyzerLap.Elapsed;
                    if(eng_retCode<0)  return;
                }
                AnalyzerLap.Stop();        

                var (_,nP,nZ,nM) = AnMan.Aggregate_CellsPZM(pBOARD);
                eng_retCode=nM;
            }
            catch(OperationCanceledException){}
            catch(Exception e){
                WriteLine( e.Message+"\r"+e.StackTrace );
                using(var fpW=new StreamWriter("Exception_201_0.txt",true,Encoding.UTF8)){
                    fpW.WriteLine($"---{DateTime.Now} {e.Message} \r{e.StackTrace}");
                }
            }
        }

        // 1-step solver
        public (bool,string) sudoku_Solver_SingleStage( CancellationToken ct, /*ref int ret2,*/ bool SolInfoB ){
            if(__ChkPrint__) WriteLine( $"\n=== stageNo:{stageNo}" );

            this.ct = ct;
            Stopwatch AnalyzerLap = new Stopwatch();
            bool mltAnsSearcB = SDK_Ctrl.MltAnsSearch;
            bool AnalysisResult = false;
            int  mCC=0, notFixedCells=0, freeDigits=0;

            // --- Initialize ---
            GNPX_App.GMthdOption["Canceled"] = "";
            pPZL.Sol_ResultLong = "";
            var (lvlLow,lvlHgh) = Set_AcceptableLevel( );
			AdditionalMessage = "";
            
            pPZL.extResult = "";

            do{
                try{
					if( pBOARD.All(p=>(p.FreeB==0)) ) break; // All cells confirmed.
                    #region  Verify the solution
                    if( !AnMan.Verify_SUDOKU_Roule() ){
                        if( SolInfoB )  pPZL.Sol_ResultLong = "no solution";
                        return (false,"no solution");
                    }


            //    #if DEBUG
            //        bool errorB = DebugSolCheck_Check();
            //    #endif

                    #endregion  Verify the solution
                            
                    AnalyzerLap.Start();
                    DateTime MltAnsTimer = DateTime.Now;

                    //===================================================================================
					if( stageNo == 0 )  PZLMan.method_maxDiffcult = null;

                    pPZL.SolCode=-1;
                    bool L1SolFound=false;
                    foreach( var P in MethodLst_Run ){                                  // Sequentially execute analysis algorithms
                        if( ct.IsCancellationRequested ){ return (false,"canceled"); }   // Was the task canceled?

                        #region Execution/interruption of analysis method by difficulty 
                        if( L1SolFound && P.difficultyLevel>=2 )  goto LBreak_Analyzing;       //Stop if there is a solution with a difficulty level of 2 or less.

                        int lvl = P.difficultyLevel; 
                        int lvlAbs = Abs(lvl);
                        if( lvlAbs > lvlHgh )  continue;                                // Eliminate methods with difficulty above the limit
                        if( !mltAnsSearcB && lvl<0 )  continue;  // The negative level algorithm is used only with multiple soluving.
                        #endregion Execution/interruption of analysis method by difficulty 

                        #region Algorithm execution
                        try{
                                if(__ChkPrint__) WriteLine( $"---> stageNo:{stageNo}  difficultyLevel:{P.difficultyLevel}  method: {(mCC++)} - {P.MethodName}");
                            // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
                            GNPZ_Engin.AnalyzingMethod = P;
                            AnalysisResult = P.Method();            // <--- Execute
                            // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*

                            if( AnalysisResult ){ // Solved
                                if(__ChkPrint__) WriteLine( $"========================> solved {P}" );
                                if( PZLMan.method_maxDiffcult==null || P.difficultyLevel>PZLMan.method_maxDiffcult.difficultyLevel ){
									PZLMan.method_maxDiffcult = P;
									method_maxDiffcult0 = P;
								}

                                // --- analysis is successful!  save the method and difficulty.
                                if( P.difficultyLevel<=2 )  L1SolFound=true;
                                P.UsedCC++;                  // Counter for the number of times the algorithm has been applied
                                pPZL.pMethod = P;    
										//WriteLine( $" +++@@@ sudoku_Solver_SingleStage : {P}" );

                                if( !mltAnsSearcB )  goto LBreak_Analyzing;     // Abort if single search
                                else{
								
								}
                                // -------------------------------------------
                                if( (string)GNPX_App.GMthdOption["abortResult"]!="" )  break; // "time over"...
                            }
                        }
                        catch( Exception e ){
                            string stException = e.Message + "\r" + e.StackTrace;
                            WriteLine( stException );
                            GNPX_App.GMthdOption["abortResult"] = stException;
#if DEBUG
                            using (var fpW=new StreamWriter("Exception_in_Engin.txt",true,Encoding.UTF8)){ // message for debug 
                                fpW.WriteLine($"\n---{DateTime.Now}\n{stException}");
                            }
#endif
                            break;
                        }
                        #endregion  Algorithm execution
                    } 
                    //----------------------------------------------------------------------------
/*
                    if( mltAnsSearcB ){
                        if( child_PZLs.Count > 0 ){
                            pPZL = child_PZLs.First();
                            SDK_Ctrl.UGPMan.pPZL = pPZL;
                            AnalysisResult = true;
                            goto LBreak_Analyzing;
                        }
                    }
*/
                                    if(__ChkPrint__) WriteLine( "========================> can not solve");
                    if( SolInfoB )  pPZL.Sol_ResultLong = "no solution";
                    return (false,"no solution");
                }
                catch(OperationCanceledException){}
                catch(Exception e){
                        WriteLine( $"{e.Message}\r{e.StackTrace}" );
#if DEBUG
                        using(var fpW=new StreamWriter("ExceptionXXX_2.txt",true,Encoding.UTF8)){
                            fpW.WriteLine($"---{DateTime.Now} {e.Message} \r{e.StackTrace}");
                        }
#endif
                        break;
                }
                finally{
                    AnalyzerLap.Stop();
                    SDK_Ctrl.solLevel_notFixedCells = notFixedCells = pBOARD.Count(p => (p.FreeB!=0));
                    SDK_Ctrl.solLevel_freeDigits = freeDigits = pBOARD.Aggregate(0,(t,p)=>t+p.FreeBC);
                }

            }while(notFixedCells>0);

            if( notFixedCells <= 0 ){ AnalysisResult=true; }  //solved

          LBreak_Analyzing:  //found
            SdkExecTime = AnalyzerLap.Elapsed;

            PZLMan.selectedIX = (child_PZLs!=null && child_PZLs.Count>0 )? 0: -1;
            return (AnalysisResult,"");  // "": "solved"  



            // --------------------------------------- inner functions ---------------------------------------
            (int,int) Set_AcceptableLevel( ){
                string AnalyzerMode = pGNP00.AnalyzerMode;
                int _lvlLow = 1;
                int _lvlHgh = 5;

                if( AnalyzerMode == "CreatePuzzle"  ){
                    _lvlLow = SDK_Ctrl.lvlLow;
                    _lvlHgh = SDK_Ctrl.lvlHgh;
                }
                else if( AnalyzerMode=="Solve" || AnalyzerMode=="SolveUp" ){     // ... ?
                    _lvlLow = 1;
                    _lvlHgh = 20;
                }
                else if( AnalyzerMode=="SolveUpDev" ){     // ... ?
                    _lvlLow = 1;
                    _lvlHgh = 12;
                }
                else if( AnalyzerMode == "MultiSolve" ){
                    _lvlLow = 1;
                    _lvlHgh = (int)GNPX_App.GMthdOption["MSlvrMaxLevel"];
                }
					//WriteLine( $" * * * Set_AcceptableLevel : {_lvlLow} - {_lvlHgh}" );
                return (_lvlLow,_lvlHgh);
            }

        }
      #endregion Analyzer

    }
}