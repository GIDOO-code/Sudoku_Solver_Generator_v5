using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Xml.Linq;

#if false
namespace GNPXcore {

    public partial class ULogical_Node: IComparable{   // Logical Unit Element

        static private readonly UInt128 _b9  = 0x1FF;
        static private readonly UInt128 _b1  = 1;

	// ==============================================================================================

		public int       ID=0;

		public UInt128   b081;
		public int       no;
		public int       pmCnd;
		public bool      used;

		public ULogical_Node( ){ }   // b081=(UInt128)77; no=10; pmCnd=3; } <-- for DEBUG

		public ULogical_Node( int no, int rc, int pmCnd, int ID=0 ){ 
			this.no=no; this.b081=UInt128.One<<rc; this.pmCnd=pmCnd; this.ID=ID;
        }
        public ULogical_Node( int no, UInt128 b081, int pmCnd, int ID=0 ){ 
        this.no=no; this.b081=b081; this.pmCnd=pmCnd; this.ID=ID;
       
		public UInt128 matchKey2  => b081 | ((UInt128)no)<<81;				//b081, no
		public UInt128 matchKey3  => b081 | ((UInt128)(no | pmCnd<<4))<<81;	//b081, no, pmCnd

        public int     rc		  => b081.BitToNum(sz:81);

		public int	   rcbFrame	  => b081.Ceate_rcbFrameOr(); // (1<<(rc.ToBlock()+18)) | (1<<(rc%9+9)) | (1<<rc/9); }

        public int     b081Size   => b081.BitCount();

        public string  TFmark     => (pmCnd==1)? "+": "-";

        public int b081_FindFirst_rc(){
            UInt128 w = b081;
            for( int rc=0; rc<81; rc++ ){
                if( (w&_b9) == 0 ){ w>>=9; rc+=8; continue;}
                if( (w&_b1)>0 )  return rc;
                w >>= 1;
            }

            return -1;
        }

        public int CompareTo( object obj ){�@// @@@ eNetwork �ŗp���Ă���BGeneralLogic�ł͎g���Ă��Ȃ�
            var Xobj = obj as ULogical_Node;
            if( Xobj is null  )  return -1;
            var dif = this.matchKey3-Xobj.matchKey3;
            int ret = (dif<0)? -1: (dif>0)? 1: 0;
            return ret;
        }
		public int CompareToA( ULogical_Node B ){
            var Xobj = B as ULogical_Node;
            if( Xobj is null  )  return -1;
			if( this.no !=B.no )  return (this.no-B.no);
            if( this.b081 == B.b081 ) return 0;
            return (this.b081<B.b081)? -1: +1;
        }


        public override int GetHashCode(){
            int hashValue = matchKey3.GetHashCode();  // <-- (b081,no,pmCnd)
            return hashValue;
        }

        public string ToString_eN(){					// @@@ 594 eNetwork_App_NiceLoopEx.cs L316
	  //public override string ToString_eN(){
            string st = $"{ToString_SameHouseComp()}#{no+1}{ToString_pmCnd()}";
            if( ID>0 )  st += $" {ID}";
            return st;
            
            string ToString_pmCnd() => ( (pmCnd==1)? "+": (pmCnd==0)? "-": "*");
        }

		public string ToStringA(){
			string stIDno = $"ID:{ID:0000} no:#{no+1} {ToString_pmCnd()}";
			string strc = $"rc:{ToString_SameHouseComp().PadRight(18)} {b081.ToBitString81()}";

            return (stIDno+strc);
            
            string ToString_pmCnd() => ( (pmCnd==1)? "+": (pmCnd==0)? "-": "*");
        }
		public string ToStringB(){
			string stID = $"ID:{ID:0000}";
			string strc = $" rc:{ToString_SameHouseComp().PadRight(18)} {b081.ToBitString81()}";
			string stno = $" no:#{no+1}";

            return (stID+strc+stno);
            
            string ToString_pmCnd() => ( (pmCnd==1)? "+": (pmCnd==0)? "-": "*");
        }


        public string ToString_SameHouseComp(){
            string st = $"{ToRCBString().ToString_SameHouseComp()}";
            return st.Trim();
        }

        public string ToRCBString(){
            string st="";
            for(int n=0; n<3; n++){
                int bp = (int)( b081 >> (n*27) );
                for(int k=0; k<27; k++){
                    if((bp&(1<<k))==0)  continue;
                    int rc=n*27+k;
                    st += $" {rc.ToRCString()}";
                }
            }
            return st.Trim();
        }

    }

}
#endif
