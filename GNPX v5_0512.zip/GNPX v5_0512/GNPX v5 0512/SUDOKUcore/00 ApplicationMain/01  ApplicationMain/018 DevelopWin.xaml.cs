﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;
using System.Text;
using System.Xml.Linq;
using System.Windows.Threading;

using static System.Math;
using static System.Diagnostics.Debug;

using GIDOO_space;

namespace GNPXcore{
    using pRes=Properties.Resources;
    public partial class DevelopWin: Window{
        private NuPz_Win            pGNP00win;
        public  GNPZ_Graphics       SDKGrp;
        private RenderTargetBitmap  bmpGZero;
        private List<UCell>         ppBDL;
        private bool                sNoAssist=true;

        public  GNPX_App            pGNP00 => pGNP00win.GNPX_000;
        private GNPZ_Engin          pGNPX_Eng => pGNP00.pGNPX_Eng;
        private GNPX_AnalyzerMan    pAnMan => pGNPX_Eng.AnMan;

        private PuzzleTrans         PTrans;

        private UPuzzle             P0_dev;
        private UPuzzle             P1_sol;
        private DispatcherTimer     onWorkingTimer;
        private int                 onWorkingCounter=0;

        static private string       pathName = "develop/";


        private string              fName_Transformed_1Removed        => pathName+"hardSuDoKu_Transformed_1Removed.txt";
        private string              fName_Transformed_12Added         => pathName+"hardSuDoKu_Transformed_12Added.txt";
        private string              fName_Transformed_X = null;
        private string              fName_CharacteristicAnalysis      => pathName+"hardSuDoKu_CharacteristicAnalysis.txt";

        private string              fName_GNPX_Solution               => pathName+ "hardSuDoKu_GNPX_Solution.txt";
        private string              fName_TryAndError_Solution        => pathName+ "hardSuDoKu_TryAndError_Solution.txt";
        private string              fName_TryAndError_SolutionSummary => pathName+ "hardSuDoKu_TryAndError_SolutionSummary.txt";        
        private ALSLinkMan          ALSMan;

    #region Main, Service
        public DevelopWin( NuPz_Win pGNP00win ){
            InitializeComponent();
            GNPXGNPX.Content = G.GNPXvX;
            this.MouseLeftButtonDown += (sender, e) => this.DragMove();

            this.pGNP00win = pGNP00win;           

            SDKGrp = new GNPZ_Graphics(pGNP00win.GNPX_000);
            bmpGZero = new RenderTargetBitmap((int)dev_GBoard.Width,(int)dev_GBoard.Height, 96,96, PixelFormats.Default);

            SDKGrp.GBoardPaint(bmpGZero, (new UPuzzle()).BOARD);
            dev_GBoard.Source = bmpGZero;
            lbl_fNmae.Content = "nothing assigned";

            PTrans = new PuzzleTrans(pGNP00);

            elpOnWork.Visibility = Visibility.Hidden;

            onWorkingTimer = new DispatcherTimer(DispatcherPriority.Normal, this.Dispatcher);
            onWorkingTimer.Interval = TimeSpan.FromMilliseconds(100);
            onWorkingTimer.Tick += new EventHandler(onWorkingTimer_Tick);
        }

        private void onWorkingTimer_Tick(object sender, EventArgs e ){
            onWorkingCounter++;
            onWorkingCounter %= 5;
            if( onWorkingCounter < 3 )  elpOnWork.Visibility=Visibility.Hidden;
            else elpOnWork.Visibility = Visibility.Visible;
            WriteLine( $"onWorkingCounter:{onWorkingCounter}");
        }

        private void devWinClose_Click(object sender, RoutedEventArgs e){
            this.Hide();
        }
    #endregion Main, Service


    #region read, deform

        private void btnReadPuzzle_Click(object sender, RoutedEventArgs e){
            pathName = pGNP00win.Read_Puzzle()+"/";
            P0_dev = pGNP00win.GNPX_000.Get_Puzzle_n(0);
            lblMessafg.Content = (P0_dev==null)?"Puzzle undefined.": "";
            if( P0_dev != null ) Set_dev_GBoard(P0_dev.BOARD, dispOn:sNoAssist);
        }
        private void chbAnalyze00_Checked(object sender, RoutedEventArgs e){
            if (bmpGZero == null) return;
            sNoAssist = (bool)chbShowCandidate.IsChecked;//chbShowNoUsedDigits
            if( P0_dev !=null )  Set_dev_GBoard(P0_dev.BOARD, dispOn:sNoAssist );
        }
        public void Set_dev_GBoard( List<UCell> pBOARD, bool dispOn=false ){
            ppBDL = pBOARD;
            pAnMan.Update_CellsState(ppBDL, setAllCandidates:true);
            SDKGrp.GBoardPaint( bmpGZero, pBOARD, sNoAssist:sNoAssist);
            dev_GBoard.Source = bmpGZero;
        }
        private void devWin_IsVisibleChanged( object sender, DependencyPropertyChangedEventArgs e ){
            if(ppBDL==null)  return;
            SDKGrp.GBoardPaint( bmpGZero, ppBDL, sNoAssist:true );
            dev_GBoard.Source = bmpGZero;
        }

        private void chbShowSolution_Checked(object sender, RoutedEventArgs e ){
            if( P0_dev==null )  P0_dev = new UPuzzle( pGNPX_Eng.pBOARD, resetB:true );
            P1_sol = pGNP00win.TransSolverA("Checked", true);
            if( P1_sol ==null ){
                lblMessafg.Content = "This is an unsolvable puzzle.";
                return;
            }

            UPuzzle PX = ((bool)chbShowSolution.IsChecked)? P1_sol: P0_dev;
            SDKGrp.GBoardPaint(bmpGZero, PX.BOARD, sNoAssist: sNoAssist);
            dev_GBoard.Source = bmpGZero;
            pGNP00._Develop_Puzzle = PX.BOARD;

            Output_Develop_SuDoKuName(PX.BOARD);
            return;


            // ----- inner function -----
            void Output_Develop_SuDoKuName( List<UCell> pBOARD ){
                string st = "";
                int rc=0;
                foreach( var P in  pBOARD ){
                    st += (P.No==0)? ".": $"{Math.Abs(P.No)}";
                    if( (++rc)%9 == 0 ) st += " ";
                }

                if( rc>=81 ){
                    using( var fpW=new StreamWriter(pGNP00._Develop_SuDoKuName, false, Encoding.UTF8) ){
                        fpW.WriteLine(st);
                    }
                }
            }
        }


        private void btnGenerate_Puzzle_1Removed_Click(object sender, RoutedEventArgs e) {
            if( !Directory.Exists(pathName) )  Directory.CreateDirectory(pathName);

            var rcNotZero = P0_dev.BOARD.FindAll(p=>p.No!=0);
            int nSize = rcNotZero.Count;
            using(var fpW = new StreamWriter(fName_Transformed_1Removed, false, Encoding.UTF8)){
                for( int n=0; n<nSize; n++ ){       
                    var solCan = P0_dev.BOARD.ConvertAll(p=>p.No);
                    int rcRem = rcNotZero[n].rc;
                    solCan[rcRem] = 0;

                    string record = string.Join("",solCan).Replace("0",".");
                    fpW.WriteLine(record);
                }
            }
            fName_Transformed_X = fName_Transformed_1Removed;
            lbl_fNmae.Content = fName_Transformed_X;
        }

        private void btnGenerate_Puzzle_12Add_Click_1(object sender, RoutedEventArgs e){
            // Add 1-2 numbers to Hard SuDoKu
        
            P0_dev = pGNP00win.GNPX_000.Get_Puzzle_n(0);    // Puzzle to be analyzed
            P1_sol = pGNP00win.GNPX_000.Get_Puzzle_n(1);    // Solution
            if( P0_dev==null || P1_sol==null ){
                lblMessafg.Content = $"P0_dev:{((P0_dev==null)?"null":"ok")}  P1_sol:{((P0_dev==null)?"null":"ok")}";
                return;
            }

            if( !Directory.Exists(pathName) )  Directory.CreateDirectory(pathName);
            var Q = P0_dev.BOARD.ConvertAll(p=>p.No.ToString());
            List<UCell> SelZero = new List<UCell>();
            foreach( var P in P0_dev.BOARD.Where(p=>p.No==0) ) SelZero.Add(P);
            List<int> solCan = new List<int>();
            foreach (var P in P0_dev.BOARD ) solCan.Add(P.No);

            // Generate a puzzle file with 1-2 cells returned to blank.
            using(var fpW = new StreamWriter(fName_Transformed_12Added, false, Encoding.UTF8)){
                for( int n=1; n<=2; n++ ){ 
                    int[] indx = new int[n]; 
                    Combination cmb = new Combination(SelZero.Count,n);
                    int nxt = 1;
                    while (cmb.Successor(skip: nxt)){
                        for( int k=0; k<n; k++ ){
                            int mx = cmb.Index[k];
                            int rc = SelZero[mx].rc;
                            solCan[rc] = P1_sol.BOARD[rc].No;
                            indx[k] = rc;
                        }
                        string record = string.Join("",solCan).Replace("0",".");
                        fpW.WriteLine(record);

                        for( int k=0; k<n; k++ ) solCan[indx[k]] = 0;
                    }
                }
            }
            fName_Transformed_X = fName_Transformed_12Added;
            lbl_fNmae.Content = fName_Transformed_X;
        }
    #endregion read, deform       
   
        private void CharacteristicAnalysis_Click(object sender, RoutedEventArgs e) {

            using( var fpW=new StreamWriter(fName_CharacteristicAnalysis, false, Encoding.UTF8) ){
                int[] numLst = new int[10];
                
                foreach( var P in P0_dev.BOARD ){
                    int n = P.FreeBC;
                    numLst[n]++;
                }
                string st = "number of elements:";
                for( int n=0; n<10; n++ )  st += $" {n}:{numLst[n]}";
                fpW.WriteLine( st ); 
                WriteLine( st );
            }
        }

    #region Solve        

        private void btnSolveContinuously_Click(object sender, RoutedEventArgs e){
            // Solve problems with GNPX.

            if ( !File.Exists(fName_Transformed_X) ){
                lblMessafg.Content = $"file:{fName_Transformed_X} is not exist.";
                return;
            }

            onWorkingTimer.Start();
            pGNP00.pGNPX_Eng.Set_Methods_for_Solving(AllMthd: false);  //true:All Method 
            string stR;
            int nc = 0;
            pGNP00.AnalyzerMode = "SolveUpDev";
            UPuzzle UP = new UPuzzle();
            using( var fpR=new StreamReader(fName_Transformed_X) )
            using( var fpW=new StreamWriter(fName_GNPX_Solution, false, Encoding.UTF8) ){
                while( (stR= fpR.ReadLine()) != null ){
                    stR = stR.Substring(0,81);
                    UP.BOARD = pGNP00._stringToBDL(stR);
                    string stSolM= pGNP00.SetSolution( UP, SolSet2:true, SolAll:true );
                    string stSol="";
                    pGNPX_Eng.pBOARD.ForEach(q => { stSol += Abs(q.No).ToString(); });

                    stSol = stSol.Replace("0",".");
                    string st = $"{stR} {stSol} {stSolM}";
                    fpW.WriteLine( st );                   
                    this.Dispatcher.Invoke(() => { lblDone.Content = $"{(++nc)}"; });
                }
            }
            onWorkingTimer.Stop();
            elpOnWork.Visibility = Visibility.Hidden;
            return;
        }

        private void btnSolve_TryAndError_cont_Click( object sender,RoutedEventArgs e ){
            // solve the problem by trial and error.
//z            fName_reducedPuzzle = pathName+"hardSuDoKu_reduced.txt";
            if( !File.Exists(fName_Transformed_X) ){
                lblMessafg.Content = $"file:{fName_Transformed_X} is not exist.";
                return;
            }

            onWorkingTimer.Start();
         // pGNP00.pGNPX_Eng.Set_Methods_for_Solving(AllMthd: false);  //true:All Method 

            string stR;
            int nc = 0;
            pGNP00.AnalyzerMode = "SolveUpDev";
            UPuzzle UP = new UPuzzle();

            using( var fpR=new StreamReader(fName_Transformed_X) )

            using( var fpW=new StreamWriter(   fName_TryAndError_Solution, false, Encoding.UTF8) )
            using( var fpWSum=new StreamWriter(fName_TryAndError_SolutionSummary, false, Encoding.UTF8) ){
                while( (stR= fpR.ReadLine()) != null ){
                    stR = stR.Substring(0,81);
                    UP.BOARD = pGNP00._stringToBDL(stR);

                    WriteLine( $"\r{stR}");
                    Research_trial RT =  pGNPX_Eng.Set_Methods_for_Solving_TaE();
                    pGNP00.SetSolution( UP, false, SolAll:true ); //Solver
                    var SolList =  RT.Get_solList;

                    fpWSum.WriteLine( $"{stR} solutions:{SolList.Count}" );
                    fpW.WriteLine( $"{stR} solutions:{SolList.Count}" );
                    foreach( var sol in SolList ){
                        string stSolM = sol.Aggregate("", (s,p)=> s+Abs(p).ToString() );
                        fpW.WriteLine(stSolM);
                        WriteLine(stSolM);
                    }
                    fpW.WriteLine( "" );
                    this.Dispatcher.Invoke(() => { lblDone_TaE.Content = $"{(++nc)}"; });
                }
            }
            onWorkingTimer.Stop();
            elpOnWork.Visibility = Visibility.Hidden;
            return;
        }
    #endregion Solve



    #region SaveBitMap
        private void SaveBitMap_Click( object sender, RoutedEventArgs e ){
            BitmapEncoder enc = new PngBitmapEncoder(); // JpegBitmapEncoder(); BmpBitmapEncoder();
            BitmapFrame bmf = BitmapFrame.Create(bmpGZero);
            enc.Frames.Add(bmf);
            try{
                Clipboard.SetData(DataFormats.Bitmap,bmf);
            }
            catch(System.Runtime.InteropServices.COMException){ /* NOP */ }

            if( !Directory.Exists(pRes.fldSuDoKuImages) ){ Directory.CreateDirectory(pRes.fldSuDoKuImages); }
            string fName=DateTime.Now.ToString("yyyyMMdd HHmmss Develop")+".png";
            using( Stream stream = File.Create(pRes.fldSuDoKuImages+"/"+fName) ){
                enc.Save(stream);
            }      
            
            lblMessafg.Content = "saved:"+ fName;
        }
    #endregion SaveBitMap



        private void btnAnalysisALS_Click( object sender, RoutedEventArgs e ){
            if( ALSMan is null ) ALSMan = new ALSLinkMan(pAnMan);

            ALSMan.Initialize();
            int minSize = nUD_ALS_minSize.Value;
            int nPlus   = nUD_ALS_plus.Value;
            ALSMan.Prepare_ALSLink_Man( nPlus, 1, setCondInfo:true, debugPrintB:true );

            if( ALSMan.ALSList==null ) return;
            ALSMan.QSearch_Cell2ALS_Link();  //LinkCeAlsLst[rc]

            string fName_ALS_Analyzing = pathName+"hardSuDoKu_ALS_Analyzing.txt";
            using( var fpW=new StreamWriter(fName_ALS_Analyzing, false, Encoding.UTF8) ){

                string st = $" Cell -> ALS";
                WriteLine(st); fpW.WriteLine(st);

                foreach( var P in ALSMan.LinkCeAlsLst.Where(p=>p!=null && p.Count>1) ){
                    st = $"rc:{P[0].UC.rc} count:{P.Count}";
                    WriteLine(st); fpW.WriteLine(st);

                    for( int k=0; k<P.Count; k++ ){ 
                        st = $"k:{k} :{P[k]}";
                        WriteLine(st); fpW.WriteLine(st);
                    }

                    Combination cmb = new Combination(P.Count,2);
                    while( cmb.Successor() ){
                        var UL = P[cmb.Index[0]];
                        var UA = P[cmb.Index[0]].ALS;
                        var UB = P[cmb.Index[1]].ALS;

                        int RCC = ALSMan.Get_AlsAlsRcc(UA, UB);
                        if( RCC == 0 )  continue;
                        st = $"\r\r rc:{UL.UC.rc} RCC:{RCC.ToBitString(9)}\r 1*{UA}\r 2*{UB}";
                        WriteLine(st); fpW.WriteLine(st);
                    }
                }
            }
        }


    }
}
