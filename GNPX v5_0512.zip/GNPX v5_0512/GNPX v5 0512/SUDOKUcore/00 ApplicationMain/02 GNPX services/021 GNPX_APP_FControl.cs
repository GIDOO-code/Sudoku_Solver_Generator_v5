﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

using static System.Math;
using static System.Diagnostics.Debug;

using System.Windows.Media;
using System.Threading;

using GIDOO_space;
using System.Globalization;
using System.Text.RegularExpressions;
//using System.Drawing;
//using System.Drawing;


namespace GNPXcore{

    // For simple version:
    //   Not modified for consistency with the regular version.
    //   Therefore, this contains unnecessary definitions and declarations.
    //

    public partial class GNPX_App{
        public NuPz_Win         pGNP00win;
        static public double    pixelsPerDip;
        static public bool[]    SlvMtdCList = new bool[60];
        static public bool      chbConfirmMultipleCells;
        static public Dictionary<string,object> GMthdOption;
        static public Dictionary<string,Color> ColorDic=new Dictionary<string,Color>();  
        static public DateTime  MultiSolve_StartTime = DateTime.Now;
        static public string    fNamePara;

//      static public bool      developMode=false;
        static public bool      digitColoring = false;

        public int              cellSize = 36;
        public int              cellSizeP;
        public int              lineWidth = 1;
        public GFont            gsFont = new GFont( "Times New Romaon", 22 );

        
        public SDK_Ctrl         SDKCntrl;                       //Puzzle Generator
        public GNPZ_Engin       pGNPX_Eng;                      //Analysis Engine
        public UPuzzleMan       pPZLMan  => pGNPX_Eng.PZLMan;   //current Puzzle is in pGNPX_Eng
        public UPuzzle          pPZL{ get=>pPZLMan.PZL; set=>pPZLMan.PZL=value; }  //current Puzzle is in pGNPX_Eng

        public string           SDK_MethodsFileName = "SDK_Methods_V5.txt";
        public string           _Develop_SuDoKuName = "_Develop_SuDoKu.txt";
        public List<UCell>      _Develop_Puzzle = null;

        public List<UPuzzle>    SDK_PUZZLE_List = new List<UPuzzle>();

        public int[]            SDK81;

        private int             _current_Puzzle_No;
        public int              current_Puzzle_No{
            get=>_current_Puzzle_No;
            set{ 
                int nn=value;
                if( nn == 888888888 ) nn = _current_Puzzle_No;
                if( nn == 999999999 ) nn = SDK_PUZZLE_List.Count-1;
                if( nn<0 ) nn=0;
                if( SDK_PUZZLE_List.Count>0 ){
                    if( nn>=SDK_PUZZLE_List.Count ) nn = SDK_PUZZLE_List.Count-1;
                    _current_Puzzle_No = nn;
                    pGNPX_Eng.Set_NewPuzzle( SDK_PUZZLE_List[nn] );
                }
            }
        }

        public GNPZ_Graphics    SDKGrp;             //board bitmap
  
        public string           GSmode = "tabACreate";
        public int              SelectedIndexPre = 0;
        public string           AnalyzerMode;

        public List<UAlgMethod> SolverLst1 = new List<UAlgMethod>();
        public List<UMthdChked> SolverLst2 = new List<UMthdChked>(); //valid analysis routines List
        public List<string>     LanguageLst;
   
        public PuzzleTrans      PTrans;             //Transform 
        public int              FreeBmask = 0;

        static GNPX_App( ){
            GMthdOption = new Dictionary<string,object>();
			GMthdOption["RandomSeed"]			= 0;
            GMthdOption["MSlvrMaxLevel"]        = 13;
            GMthdOption["MSlvrMaxAlgorithm"]    = 50;
            GMthdOption["MSlvrMaxAllAlgorithm"] = 400;
            GMthdOption["MSlvrMaxTime"]         = 10;   //sec
            GMthdOption["RecommendLevel"]       = 20;	// Restricted within the program. Cannot be changed at runtime

            GMthdOption["StartTime"]            = DateTime.Now;
            GMthdOption["abortResult"]          = "";
        
            GMthdOption["NiceLoopMax"]          = 10;
            GMthdOption["ALSSizeMax"]           = 5;
            GMthdOption["ALSChainSizeMax"]      = 8;

            GMthdOption["Cell"]                 = true;
            GMthdOption["AIC"]                  = true;
            GMthdOption["ALS"]                  = true;
            GMthdOption["ALSXZ"]                = false;
            GMthdOption["AnLS"]                = false;
            GMthdOption["eALS"]					= false;
			GMthdOption["ForceLx"]              = "ForceL2";
			GMthdOption["ShowProofMultiPaths"]  = false;
        
			GMthdOption["PreferSimpleLinks"]    = 1;
            GMthdOption["Use_eALS"]			    = 1;

            GMthdOption["GeneralLogic_on"]      = false;          
            GMthdOption["GenLogMaxSize"]        = 3;
            GMthdOption["GenLogMaxRank"]        = 1;
            GMthdOption["Canceled"]             = "";

            GMthdOption["ForceChain_on"]        = true;   // Always ON!
            GMthdOption["UCellLinkExt"]         = true;
            GMthdOption["DebugSolCheckMode"]    = false;
        

            ColorDic = new Dictionary<string,Color>();
            ColorDic["Board"]        = Color.FromArgb(255,220,220,220);
            ColorDic["BoardLine"]    = Colors.Navy;

            ColorDic["CellForeNo"]   = Colors.Navy;
            ColorDic["CellBkgdPNo"]  = Color.FromArgb(255,160,160,160);
            ColorDic["CellBkgdMNo"]  = Color.FromArgb(255,190,190,200);
            ColorDic["CellBkgdZNo"]  = Colors.White;
            ColorDic["CellBkgdZNo2"] = Color.FromArgb(255,150,150,250);

            ColorDic["CellBkgdFix"]  = Colors.LightGreen;
            ColorDic["CellFixed"]    = Colors.Red;
            ColorDic["CellFixedNo"]  = Colors.Red;
        }



        public GNPX_App( NuPz_Win pGNP00win ){
            List<string> DirLst=Directory.EnumerateDirectories(".").ToList();
            LanguageLst=new List<string>();
            LanguageLst.Add("en");
            foreach( var P in DirLst ){
                var Q=P.Replace(".","").Replace("\\","");
                if(Q=="en")  continue;
                if(Q.Length==2 ||(Q[2]=='-' && Q.Length==5)) LanguageLst.Add(Q);
            }

            LanguageLst = LanguageLst.FindAll(P=>(P.Length==2 ||(P[2]=='-' && P.Length==5)));
            LanguageLst.Sort();

            this.pGNP00win = pGNP00win;
            cellSizeP  = cellSize+lineWidth;
            SDKCntrl   = new SDK_Ctrl(this,0);

            //=======================================================
            pGNPX_Eng   = new GNPZ_Engin( this );                   // unique in the system
            pGNP00win.GNPX_Develop_prepare( this );    // for development, read solution
            //-------------------------------------------------------

            SDK_Ctrl.pGNPX_Eng = pGNPX_Eng;
            PTrans = new PuzzleTrans(this);
            SolverLst2 = new List<UMthdChked>();

            // ==============================

            //-------------------------------
        }


        public bool GNPX_App_Initialize(){
            AnalyzerMode = "Solve";
            UPuzzle tPZL = GetCurrentProble();
            if( tPZL is null )  return false;
            pGNPX_Eng.Set_NewPuzzle(tPZL);

            pGNPX_Eng.AnalyzerCounterReset( );
            pGNPX_Eng.AnMan.ResetAnalysisResult(true);   //Return to initial state
            pGNPX_Eng.AnMan.Update_CellsState( pGNPX_Eng.pBOARD );
            SDK_Ctrl.UGPMan=null;                       //initialize Multi_solver
			pPZL.extResult="";
            return true;
        }
    }

}