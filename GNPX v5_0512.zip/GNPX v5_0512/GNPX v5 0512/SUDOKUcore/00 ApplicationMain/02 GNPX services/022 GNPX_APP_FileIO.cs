﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

using static System.Math;
using static System.Diagnostics.Debug;

using System.Windows.Media;
using System.Threading;

using GIDOO_space;
using System.Globalization;
using System.Text.RegularExpressions;
//using System.Drawing;
//using System.Drawing;


namespace GNPXcore{

    public partial class GNPX_App{

        public int SDK_FileInput( string fName, bool puzzleIniFlag ){
            char[] sep=new Char[]{ ' ', ',', '\t' };        
            string LRecord, pName="";

            using( StreamReader SDKfile=new StreamReader(fName) ){
                SDK_PUZZLE_List.Clear();

                while( (LRecord=SDKfile.ReadLine()) !=null ){
                    if( LRecord=="" ) continue;
                    
                    // Supports the format "Contain a blank every 9 digits" and similar type.
                    int n81 = Find_81Digits(LRecord);
                    if( n81 > 81 ){
                        string st = LRecord.Substring(0,n81).Replace(" ","").Replace(".","0");
                        if( st.Length==81 && st.All(char.IsDigit) ){ LRecord = st + LRecord.Substring(n81); }
                    }

                    string[] eLst = LRecord.SplitEx(sep);
                    if( LRecord[0]=='#' ){ pName=LRecord.Substring(1); continue; }		// comment line
                    if( eLst[0] == "sPos" ) continue;									// obsolete format
																						// 
                    int    nc = eLst.Length;
                    string name="";
                    int    difLvl=99;
                    if( eLst[0].Length>=81 ){
                        try{
							if( nc>=2 && eLst[1].IsNumeric() ) difLvl = eLst[1].ToInt();
							if( nc>=3 ){					   name   = eLst[2]; }  
                            string st = eLst[0].Replace(".", "0").Replace("-", "0").Replace(" ", "");
                            List<UCell> tmpBoard = _stringToBDL(st);
                            string TimeStamp =  Find_TimeStamp( eLst );
                            int ID = SDK_PUZZLE_List.Count;
                            SDK_PUZZLE_List.Add( new UPuzzle(ID,tmpBoard,name,difficultyLevel:difLvl,TimeStamp) );  
                        }
                        catch{ continue; }                   
                    }
                }

                current_Puzzle_No = 0;
                return current_Puzzle_No;

                // inner function ======================
                int Find_81Digits( string st ){
                    int n=0, m=0;
                    foreach( var p in st ){
                        m++;
                        if( (char.IsDigit(p) || p=='.') && (++n)>= 81 )  break;                
                    }
                    return (n==81)? m: 0;
                }   

                string Find_TimeStamp( string[] eList ){
                    string TimeStamp="";
                    foreach( var e in eList){
                        if( DateTime.TryParse(e,out _) ){ TimeStamp=e; break; }
                    }
                    return TimeStamp;
                }
            }   
        }


        public UPuzzle SDK_ToUPuzzle( int[] SDK81, string name="", int difLvl=0, bool saveF=false ){
            if(SDK81==null) return null;
            string st="";
            foreach( var p in SDK81 ){ 
                if(p>9) st += "0";
                else st += (p<=9)? p.ToString(): ".";
            }
            var tmpPZL=SDK_ToUPuzzle( st, name, difLvl, saveF);
            return tmpPZL;
        }
        public UPuzzle SDK_ToUPuzzle( string st, string name="", int difficultyLevel=0, bool saveF=false ){
            List<UCell> B=_stringToBDL(st);
            if(B==null)  return null;
            var tmpPZL=new UPuzzle(999999999,B,name,difficultyLevel:difficultyLevel);
            if(saveF) SDK_Save(tmpPZL);  
            return tmpPZL;
        }   

        public List<UCell> _stringToBDL( string stOrg ){
            string st = stOrg.Replace(".", "0").Replace("-", "0").Replace(" ", "");
            try{               
                List<UCell> B = new List<UCell>();
                int rc=0;
                for(int k=0; rc<81; ){
                    if(st[k]=='+'){ k++; B.Add(new UCell(rc++,-( st[k++].ToInt())) ); }
                    else{
                        while(!st[k].IsNumeric()) k++;
                        B.Add( new UCell(rc++, st[k++].ToInt() ) );
                    }
                }
                return B;
            }
            catch(Exception e){
                WriteLine($"_stringToBDL \rstOrg:{stOrg} \r   st:{st}");
                WriteLine( $"string error:{e.Message}\r{e.StackTrace}");
            }
            return null;
        }
                


        public void SDK_FileOutput( string fName, bool append, bool fType81, bool SolSort, bool SolSet, bool SolSet2, bool blank9 ){
            if( SDK_PUZZLE_List.Count==0 )  return;

            SDK_Ctrl.MultiPuzzle = 1;
            SDK_Ctrl.lvlLow = 0;
            SDK_Ctrl.lvlHgh = 999;

            string LRecord, solMessage="";
            GNPX_App.SlvMtdCList[0] = true;  //use all methods


            int m=0;
            SDK_PUZZLE_List.ForEach( p=>p.ID=(m++) );
            IEnumerable<UPuzzle> qry;
            if(SolSort) qry = from p in SDK_PUZZLE_List orderby p.difficultyLevel ascending select p;
            else qry = from p in SDK_PUZZLE_List select p;

            using( StreamWriter fpW=new StreamWriter(fName,append,Encoding.UTF8) ){
                foreach( var P in qry ){

                    //===== Preparation =====
                    solMessage = "";
                    if(SolSet) solMessage = SetSolution(aPZL:P,SolSet2:SolSet2,SolAll:SolSet);	//output Solution
                            
                    if(fType81){　//Solution(tytpe:line)
                        LRecord = ""; 
                        P.BOARD.ForEach( q => {
                            LRecord += Max(q.No,0).ToString();
                            if( blank9 && q.c==8 )  LRecord += " ";        //Supports the format "Contain a blank every 9 digits"
                        } );
                        LRecord = LRecord.Replace("0",".");

                        LRecord += $" {P.difficultyLevel} \"{P.Name}\"";
                        if(SolSet&&SolSet2) LRecord += $" \"{SetSolution(P,SolSet2:true,SolAll:true)}\"";//解出力
                        if(pPZL.TimeStamp!=null) LRecord += $" \"{pPZL.TimeStamp}\"";
                        fpW.WriteLine(LRecord);
                    }
                }
            }
            GNPX_App.SlvMtdCList[0] = false;             //restore method selection
        }
     
		public void btn_FavoriteFileOutput( bool fType81=true, bool SolSet=false, bool SolSet2=false ){
            if( SolSet ){
                var tokSrc = new CancellationTokenSource(); //procedures for suspension
                GNPX_App.SlvMtdCList[0] = true;             //use all methods
                pGNPX_Eng.AnMan.Update_CellsState( pGNPX_Eng.pBOARD );
                pGNPX_Eng.sudoku_Solver_Simple(tokSrc.Token);
            }

            string puzzleMessage;
            int difLvl = pGNPX_Eng.Get_difficultyLevel(out puzzleMessage);          
            string LRecord = "";  
            if( fType81 ){
                pPZL.BOARD.ForEach( q =>{ LRecord += Max(q.No,0).ToString(); } );
                LRecord = LRecord.Replace("0",".");  

                LRecord += $" {pPZL.difficultyLevel} \"{pPZL.Name}\"";
                if( SolSet&&SolSet2 ) LRecord += $" \"{SetSolution(pPZL,SolSet2:true,SolAll:true)}\"";//解を出力
                if( pPZL.TimeStamp!=null ) LRecord += $" \"{pPZL.TimeStamp}\"";
            }
            
            string fNameFav = "SDK_Favorite.txt";
            using( var fpW=new StreamWriter(fNameFav,true,Encoding.UTF8) ){
                fpW.WriteLine(LRecord);
            }
            GNPX_App.SlvMtdCList[0] = false;//use selected methods
        }


        public void save_created_PUZZLE( UPuzzle aPZL ){
            aPZL.ID = SDK_PUZZLE_List.Count;
            aPZL.BOARD.ForEach( p=>p.Reset_All() );

            SDK_PUZZLE_List.Add(aPZL);
            if( SDK_Ctrl.FilePut_GenPuzzle ){
                string fName = "AutoGen" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt";
                __emergencyFilePut( "AutoGen", fName );
            }
            current_Puzzle_No = SDK_PUZZLE_List.Count-1;

			 void __emergencyFilePut( string dirStr, string fName ){
				if( !Directory.Exists(dirStr) ){ Directory.CreateDirectory(dirStr); }
				using( var fpW=new StreamWriter(dirStr+@"\"+fName,false,Encoding.UTF8) ){     
					foreach( UPuzzle P in SDK_PUZZLE_List ){
						string LRecord = "";
						P.BOARD.ForEach( q =>{ LRecord += Max(q.No,0).ToString(); } );
						LRecord = LRecord.Replace("0",".");
						LRecord += $" {(P.ID+1)} \"{P.Name}\" {P.difficultyLevel} \"{P.TimeStamp}\"";
						fpW.WriteLine(LRecord);
					}
				}   
			}

		}







		// [TBD] Change to TryAndError version(?). difficult cannot be set.  ver.5.2   ###(?)

		/*
			List<int>  intBoard = pBOARD.ConvertAll(P=>Abs(P.No));
			RTrial = new Research_trial( AnMan );
			RTrial.Preparer_Research_trial( intBoard, filePutB:false );
			bool ret = RTrial.TrialAndErrorApp( );
		*/

		public string SetSolution( UPuzzle aPZL, bool SolSet2, bool SolAll=false ){
            string solMessage="";
            pPZL = aPZL;

            string puzzleMessage="";
            if( SolAll || pPZL.difficultyLevel<=0 || pPZL.Name=="" ){
                foreach( var p in aPZL.BOARD )  if( p.No<0 ) p.No=0;

                pGNPX_Eng.AnMan.Update_CellsState( aPZL.BOARD );
                pGNPX_Eng.AnalyzerCounterReset();

                var tokSrc = new CancellationTokenSource();　        //for suspension
                pGNPX_Eng.sudoku_Solver_Simple(tokSrc.Token);                      
                if( GNPZ_Engin.eng_retCode<0 ){
                    pPZL.difficultyLevel = -999;
                    pPZL.Name = "unsolvable";
                }
                else{
                    if(pPZL.difficultyLevel<=1 || pPZL.Name==""){
                        int difficult = pGNPX_Eng.Get_difficultyLevel( out puzzleMessage);
                        if(pPZL.difficultyLevel<=1)  pPZL.difficultyLevel = difficult;
                        if(pPZL.Name=="")     pPZL.Name = puzzleMessage;
                    }
                }
            }     
            solMessage = "";    //puzzleMessage;
            if(SolSet2) solMessage += pGNPX_Eng.DGViewMethodCounterToString();　//適用手法を付加
            solMessage=solMessage.Trim();

            return solMessage;
        }

    }
}