﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

using static System.Math;
using static System.Diagnostics.Debug;

using System.Windows.Media;
using System.Threading;

using GIDOO_space;
using System.Globalization;
using System.Text.RegularExpressions;
//using System.Drawing;
//using System.Drawing;


namespace GNPXcore{

	// public class UPuzzle.  ==> see "300 SDK_UPuzzle.cs"
	// Here, GNPX service.


    public partial class GNPX_App{

        public UPuzzle GetCurrentProble( ){
            UPuzzle P=null;
            if( current_Puzzle_No>=0 && current_Puzzle_No<=SDK_PUZZLE_List.Count-1 ){
                P = SDK_PUZZLE_List[current_Puzzle_No];
            }
            return P;
        }
            
        public void SDK_Save( UPuzzle aPZL ){
            aPZL.ID = SDK_PUZZLE_List.Count;
            SDK_PUZZLE_List.Add(aPZL);
        }
        public void SDK_Save_EngGP(){
            SDK_Save(pPZL);
        }   
        public void CreateNewPuzzle( UPuzzle aPZL=null ){
            if(aPZL==null) aPZL = new UPuzzle("New Puzzle");
            aPZL.ID=SDK_PUZZLE_List.Count; 
            pGNPX_Eng.Set_NewPuzzle(aPZL);
            SDK_Save(aPZL);
            current_Puzzle_No=999999999;
        }
     
        public void SDK_Save_ifNotContain(){
            if( !Contain(pPZL) )  SDK_Save_EngGP();
        }
        public void SDK_Remove(){
            int PnoMemo=current_Puzzle_No;
            if( PnoMemo==SDK_PUZZLE_List.Count-1 ) PnoMemo--;
            if( Contain(pPZL) ) SDK_PUZZLE_List.Remove(pPZL);
            current_Puzzle_No=PnoMemo;
        }

        public bool Contain( UPuzzle aPZL ){
            return (SDK_PUZZLE_List.Find(P=>P.HTicks==aPZL.HTicks)!=null);
        }

        public UPuzzle Get_Puzzle_n( int n ){
            if( n<0 || n>=SDK_PUZZLE_List.Count )  return null;
            return SDK_PUZZLE_List[n];
        }



    }

}