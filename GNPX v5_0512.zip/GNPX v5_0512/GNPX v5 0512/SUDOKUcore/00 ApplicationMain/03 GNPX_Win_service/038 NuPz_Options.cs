﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Globalization;

using System.Threading;
using System.Windows.Threading;

using GIDOO_space;

namespace GNPXcore{
    using pRes=Properties.Resources;

    //*==*==*==*==*==*==*==*==*==*==*==*==*
    // Change the expression of Sudoku.
    //*==*==*==*==*==*==*==*==*==*==*==*==*

    public partial class NuPz_Win{  //Puzzle Transform

        public object Culture{ get=> pRes.Culture; }
        string CopyrightJP, CopyrightEN;
        private void  MultiLangage_JP_Click(Object sender,RoutedEventArgs e){
            ResourceService.Current.ChangeCulture("ja-JP");
            txtCopyrightDisclaimer.Text = CopyrightJP;
            _MethodSelectionMan();
            __bruMoveSub();
        }
        private void  btnMultiLangage_Click(object sender, RoutedEventArgs e){
            ResourceService.Current.ChangeCulture("en");
            Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
            txtCopyrightDisclaimer.Text = CopyrightEN;
            _MethodSelectionMan();
            __bruMoveSub();
        }
        private void  cmbLanguageLst_SelectionChanged(Object sender,SelectionChangedEventArgs e){
            string lng=(string)cmbLanguageLst.SelectedValue;
            ResourceService.Current.ChangeCulture(lng);
            __bruMoveSub();
        }

		private void btnHomePageGitHub_Click( object sender, RoutedEventArgs e ){
            string cul=Thread.CurrentThread.CurrentCulture.Name;
            //WriteLine("The current culture is {0}", cul);
            string urlHP="";
            if(cul=="ja-JP") urlHP = "https://gidoo-code.github.io/Sudoku_Solver_Generator_v5_jp/";
            else             urlHP = "https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/"; 
          //Process.Start(urlHP);        //? in development
            HP_address.Text = urlHP;
            Clipboard.SetData(DataFormats.Text, urlHP);
            CopiedHP.Visibility = Visibility.Visible;
            GNPZExtender.ProcessExe(urlHP);
        }            private void _MethodSelectionMan(){
            GMethod00A.ForceCursor=true;          

            if(GNPX_000!=null){
                GMethod00A.ItemsSource = null; //GSel*
                GMethod00A.ItemsSource = GNPX_000.Set_MethodLis_1to2(true);
                GMethod00A.IsEnabled = true;
            }

            string st;
            bool B = (bool)GNPX_App.GMthdOption["GeneralLogic_on"];
            string cul=Thread.CurrentThread.CurrentCulture.Name;
            string st2;
            if(cul=="ja-JP") st2= B? "有効": "無効";
            else             st2= (B? "":"not ") + "available";
            LblGeneralLogic.Content = "GeneralLogic :"+ st2;
            LblGeneralLogic.Foreground = (B)? Brushes.LightBlue: Brushes.Yellow;

            B = (bool)GNPX_App.GMthdOption["ForceChain_on"];
            if(cul == "ja-JP") st2 = B ? "有効" : "無効";
            else st2 = (B? "" : "not ") + "available";

            var currentDir = Directory.GetCurrentDirectory();
            txtB_SDK_Methods.Text = Path.Combine(currentDir, GNPX_000.SDK_MethodsFileName);
        }  
    }
}