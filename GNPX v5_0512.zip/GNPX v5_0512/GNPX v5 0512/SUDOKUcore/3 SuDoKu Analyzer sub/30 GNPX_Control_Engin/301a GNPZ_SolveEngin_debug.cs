using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Windows.Media;

using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.IO;
using System.Text;



namespace GNPXcore{
    public partial class GNPZ_Engin{                        // This class-object is unique in the system.

        private Research_trial_Simple TandE;

		public  string      TandE_st_Puzzle="";

        private int[]		sol_int81;
		public  string      TandE_st_sol_int81="";
        public string       Result{   get=>pPZL.Sol_Result; set=>pPZL.Sol_Result=value; }
        public string       ResultLong{   get=>pPZL.Sol_ResultLong; set=>pPZL.Sol_ResultLong=value; }

		public string       extResult{   get=>pPZL.extResult; set=>pPZL.extResult=value; }

		private string		fName_BugInApplication;

		private object obj = new object();
        public bool  DebugSolCheck_Set( ){
            TandE = null;
			bool TandE_infoB = true;

			List<int> intBoard = pBOARD.ConvertAll( P=> Max(P.No,0) );
			TandE_st_Puzzle = string.Join("",intBoard);

			TandE = new Research_trial_Simple( intBoard );

				Stopwatch sw = new Stopwatch();
				sw.Start();
			fName_BugInApplication = $"{DateTime.Now.ToString("yyyyMMdd_hhMM")}.txt";
			bool SolCode = TandE.TrialAndErrorApp( $"Debug_{fName_BugInApplication}", onlyMultipleSolutions:true );
				var elps = sw.ElapsedMilliseconds;

			if(SolCode)  sol_int81 = TandE.Sol.ToList().ConvertAll(p=>Abs(p)).ToArray();
			if( sol_int81 !=null ){
				TandE_st_sol_int81 = string.Join("",sol_int81);
				WriteLine( $"{TandE_st_sol_int81} ... elapsed time:{elps}ms" );
			}
			else{ 
				TandE_st_sol_int81 = $"There are multiple solutions ... elapsed time:{elps}ms";
				WriteLine( TandE_st_sol_int81 );
				TandE_infoB = false;
			}

			return TandE_infoB;
        }

		public bool IsSolutionValid( ){
            if( TandE==null || sol_int81==null )  return false;

			bool errorB = pBOARD.Any( P=> (P.FixedNo>0 && P.FixedNo!=sol_int81[P.rc] ) )
						| pBOARD.Any( P=> (P.CancelB>0 && (P.CancelB & (1<<(sol_int81[P.rc]-1)))>0 ) );

			if( !errorB ) return false;

            Result += "  ... error ...";
            ResultLong += $"\n\n ... error ...\n  file:{fName_BugInApplication}"; 
			extResult = ResultLong; 

// #if DEBUG
            using( var fpW=new StreamWriter( fName_BugInApplication, append:false, encoding:Encoding.UTF8) ){
				string st0 = string.Join("",pBOARD.ConvertAll( P=> Max(P.No,0) ) );
				string st1 = string.Join("",pBOARD.ConvertAll( P=> Abs(P.No) ) );

				fpW.WriteLine( $"\n ... error ... {DateTime.Now} MethodName : {AnalyzingMethod.MethodName}" );					
				fpW.WriteLine( $"{st0.Replace("0",".")}   puzzle" );
				fpW.WriteLine( $"{st1.Replace("0",".")}   current" );
				fpW.WriteLine( $"{TandE_st_sol_int81}   Solution" );
			}
//#endif
            return errorB;
        }

		public void Emergency_FilePut(){
			lock(obj){
				fName_BugInApplication = $"{DateTime.Now.ToString("yyyyMMdd_hhMM")} Emergency.txt";
				using( var fpW=new StreamWriter( fName_BugInApplication,append:false, encoding:Encoding.UTF8) ){
					string st0 = string.Join("",pBOARD.ConvertAll( P=> Max(P.No,0) ) );
					string st1 = string.Join("",pBOARD.ConvertAll( P=> Abs(P.No) ) );

					fpW.WriteLine( $"\n Multiple Solutions. {DateTime.Now}" );		
					fpW.WriteLine( $"{st0.Replace("0",".")}   puzzle" );
					fpW.WriteLine( $"{st1.Replace("0",".")}   current" );
				}
			}
		}
    }
}