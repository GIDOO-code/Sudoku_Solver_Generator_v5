using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.IO;
using System.Text;
using System.Security.Policy;

namespace GNPXcore{

    public partial class Firework_TechGen: AnalyzerBaseV2{
        static private   UInt128 qZero  = UInt128.Zero;
        static private   UInt128 qOne   = UInt128.One; 
		private int		 stageNoPMemo = -9;
		private UInt128  BOARD81b;
		public List<UFirework> Firework_List;	
		public List<UFirework> FireworkAgg_List;

	#region 4Debug
		internal bool		debugPrint = false;
		internal string     debug_Result = "";
		internal string		fName_debug = "Firework_Triple.txt";

		
		internal void Debug_StreamWriter( string LRecord ){
#if DEBUG
			if(!debugPrint)  return;
            using( var fpW=new StreamWriter(fName_debug,true,Encoding.UTF8) ){
                fpW.WriteLine(LRecord);
            }
#endif
	
		}	
	#endregion 4Debug


		public Firework_TechGen( GNPX_AnalyzerMan pAnMan ): base(pAnMan){ }


		public void Prepare_Firework_TechGen(){
			Firework_List = IEGet_UFirework().ToList();						// Single Firework

			{// Aggregation of candidate digits 
				FireworkAgg_List = new();
				var querySL = Firework_List.GroupBy(x => x.rcStem_rc12B81);
				foreach( var group in querySL ){
					int FreeB = group.Aggregate(0, (p,q) => p|q.FreeB );	// Aggregate FreeB
					bool sw   = group.Aggregate(true, (p,q) => p & q.sw );
					UFirework UFW = group.First().Copy(sw,FreeB);
					FireworkAgg_List.Add( UFW );
				}
			}
			//Firework_List.ForEach( p=> WriteLine( $"0-{p}" ) );
			//FireworkAgg_List.ForEach( p=> WriteLine( $" 0+{p}" ) );
		}

		public class UFirework{
			public bool sw;		// true : strong type (connected by strong link).
			public int  rcStem;
			public int  FreeB;
			public int  FreeBC;
			public int  rc1;
			public int  rc2;
			public UInt128 rc12B81;
			public UInt128 rcStem_rc12B81;

			public UFirework( bool s, int rcStem, int no, int rc1, int rc2 ){
				this.sw = s;
				this.rcStem = rcStem;
				this.rc1 = Min(rc1,rc2); this.rc2 = Max(rc1,rc2);
				this.FreeB = 1<<no;
				this.FreeBC = 1;
				this.rc12B81 = qOne<<rc1 | qOne<<rc2; 
				UInt128 rc12B81 = 0;
				if( rc1 >= 0 )  rc12B81 |= (qOne<<rc1);
				if( rc2 >= 0 )  rc12B81 |= (qOne<<rc2);
				this.rcStem_rc12B81 = (UInt128.One<<rcStem) | rc12B81;
			}

			public UFirework Copy( bool sw, int FreeB=-999 ){
				UFirework UFW = (UFirework)this.MemberwiseClone();
				UFW.sw = sw;
				if( FreeB != -999 ){ UFW.FreeB=FreeB; UFW.FreeBC=FreeB.BitCount(); }
				return UFW;
			}


			public override string ToString( ){
				string st = $"UFirework Stem;{rcStem.ToRCString()} sw:{sw}";
				st += $"  FreeB:{FreeB.ToBitString(9)}  (rc1,rc2){rc12B81.ToBitString81N()}";
				return st;
			}

			public string ToStringResult( ){
				string st = $"{rcStem.ToRCString()}#{FreeB.ToBitStringN(9)} {rc12B81.ToRCStringComp()}";
				return st;
			}
			public string ToStringResultLong( ){
				string st = $"    Stem;{rcStem.ToRCString()} sw:{sw}";
				st += $" FreeB:{FreeB.ToBitStringN(9)}\n    (rc1,rc2):{rc12B81.ToRCStringComp()}";
				return st;
			}
			public override bool Equals( object obj ){
				UFirework ufw = obj as UFirework;
				if( this.FreeB != ufw.FreeB ) return false;
				return (this.rcStem_rc12B81 == ufw.rcStem_rc12B81); 
			}

			public int CompareTo( object obj ){  // for IComparable. ... don't delete
				UFirework ufw = obj as UFirework;
				if( this.rcStem != ufw.rcStem ) return (this.rcStem-ufw.rcStem);
				if( this.FreeB  != ufw.FreeB )  return (this.FreeB-ufw.FreeB);

				if( this.rc1 != ufw.rc1 )       return ( this.rc1-ufw.rc1 );
				return  (this.rc2-ufw.rc2);
			}

			public int CompareToRC( object obj ){  // for IComparable. ... don't delete
				UFirework ufw = obj as UFirework;

				if( this.rc1 != ufw.rc1 )       return ( this.rc1-ufw.rc1 );
				if( this.rc2 != ufw.rc2 )       return ( this.rc2-ufw.rc2 );

				if( this.FreeB  != ufw.FreeB )  return (this.FreeB-ufw.FreeB);

				return (this.rcStem-ufw.rcStem);
			}


		}




		private IEnumerable<UFirework> IEGet_UFirework( bool debugPrint=false ){
			BOARD81b = pBOARD.Create_bitExp128();

			foreach( UCell Stem in pBOARD.Where(p=> p.FreeBC>=2) ){
				if( Stem.FreeBC < 2 )  continue;
				int  rowH=Stem.r, colH=Stem.c+9, blkH=Stem.b+18;
				UInt128 row81 = HouseCells81[rowH];
				UInt128 col81 = HouseCells81[colH];
				UInt128 blk81 = HouseCells81[blkH];
				UInt128 fw_StemS = row81 | col81;
				UInt128 fw_Stem  = fw_StemS. DifSet(blk81);	// Target House : (Hrou|HColumn)-Block

					//WriteLine( $"Stem:{Stem}\n fw_Stem:{fw_Stem.ToBitString81N()}" );

				foreach( int no in Stem.FreeB.IEGet_BtoNo(9) ){
					UInt128 fw_Stem_no = BOARD81b9[no] & fw_Stem;
					UInt128 fw_Stem_noN = BOARD81b & fw_Stem;

					UInt128 col81Sel = row81 & fw_Stem_no;
					int rc1 = col81Sel.Get_rc_ifUnique(81);						// Target row unique cell

					UInt128 row81Sel = col81 & fw_Stem_no;
					int rc2 = row81Sel.Get_rc_ifUnique(81);						// Target clumn unique cell

					// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
					if( rc1<0 && rc2<0 )  continue;								// * missing in both directions

					int swCount = (BOARD81b9[no]&fw_StemS).BitCount();
					if( rc1>=0 && rc2>=0 ){										// * both row and column
						bool sw = (swCount == 3);
						UFirework UFW = new( sw, Stem.rc, no, rc1, rc2 );
						yield return UFW;
					}

					else if( rc1<0 && rc2>=0 && col81Sel==0 ){					// * row direction is missing
						UInt128 row81SelN = row81 & fw_Stem_noN;
						bool sw = (swCount == 2);
						foreach( var rc1N in row81SelN.IEGet_rc(81) ){
							UFirework UFW = new( sw, Stem.rc, no, rc1N, rc2 );
							yield return UFW;
						}
					}

					else if( rc1>=0 && rc2<0 && row81Sel==0 ){					// * column direction is missing
						UInt128 col81SelN = col81 & fw_Stem_noN;
						bool sw = (swCount == 2);
						foreach( var rc2N in col81SelN.IEGet_rc(81) ){
							UFirework UFW = new( sw, Stem.rc, no, rc1, rc2N );
							yield return UFW;
						}
					}
				}
			}
		}
	}

}