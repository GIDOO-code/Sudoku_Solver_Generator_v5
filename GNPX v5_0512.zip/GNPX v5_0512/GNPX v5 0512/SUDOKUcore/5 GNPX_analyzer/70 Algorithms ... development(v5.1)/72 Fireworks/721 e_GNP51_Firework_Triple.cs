using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;
using static System.Math;
using System.IO;

using GIDOO_space;
using static System.Net.Mime.MediaTypeNames;
using static System.Net.WebRequestMethods;
using System.Collections;


namespace GNPXcore{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//    under development (GNPXv5.1)
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

	//http://forum.enjoysudoku.com/fireworks-t39513.html
	//.45.........1...7.8...23......9.71........3...8.4.6.2...3.....5.7.8....6......9.. // Firework_Triple
	//..8......4....8.7.5.....3.8.1.9.4.83..2........37.6......13...9.7...2.3.......56. //  transposition
	//.857..6..3...4..1.2.......85.48.....6...2..5..9...1..3.....9..4...1....7....3728.	

	//1.....5.82.........4..9.7.6..3..2....26.8.9..5....92......73....8....1.....9...42
	//167234598259867314348195726893752461426381975571649283612473859984526137735918642

    public partial class Firework_TechGen: AnalyzerBaseV2{

        public bool Firework_Triple( ){
			// ===== Prepare =====
			if( stageNoP != stageNoPMemo ){
				stageNoPMemo = stageNoP;
				base.AnalyzerBaseV2_PrepareStage();
				Prepare_Firework_TechGen();
			}

			// ===== Analize =====
				//FireworkAgg_List.ForEach( P=> WriteLine(P) );
			var FW_Triple = FireworkAgg_List.FindAll(x => x.FreeB.BitCount()==3); //Are there any cases of 4 or more?
			foreach( var fw3 in FW_Triple ){
				bool solfound = Firework_Triple_SolResult( fw3 );
				if( !solfound ) continue;

				if( pAnMan.IsSolutionValid_Analyzer() )  return true; // @is Valid
			}
			return false;
		}

		private bool Firework_Triple_SolResult( UFirework ufw ){
			int FreeB = ufw.FreeB;
			int rc0=ufw.rcStem, rc1=ufw.rc1, rc2=ufw.rc2;
			UCell UC0=pBOARD[rc0], UC1=pBOARD[rc1], UC2=pBOARD[rc2];
			
			UC0.Set_CellBKGColor(SolBkCr);
			UC1.Set_CellBKGColor(SolBkCr2);
			UC2.Set_CellBKGColor(SolBkCr2);

			string st_Stem = $"{rc0.ToRCString()} #{UC0.FreeB.ToBitStringNZ(9)}";
			string st_Leaf = $"{rc1.ToRCString()} {rc2.ToRCString()}";

			UC0.CancelB = UC0.FreeB.DifSet(FreeB);
			UC1.CancelB = UC1.FreeB.DifSet(FreeB);
			UC2.CancelB = UC2.FreeB.DifSet(FreeB);

			if( pBOARD.Any(p=>p.CancelB>0) )  SolCode = 2;
			else{ pBOARD.ForEach(p=> p.ECrLst=null ); }

			Result     = $"Firework_Triple Stem:{st_Stem} Leaf:{st_Leaf}";
			ResultLong = $"Firework_Triple\n  Stem : {st_Stem}\n  Leaf:{st_Leaf}";

			return (SolCode== 2);
		}
	}
}