using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;
using static System.Math;
using System.IO;

using GIDOO_space;
using static System.Net.Mime.MediaTypeNames;
using static System.Net.WebRequestMethods;
using System.Diagnostics;
using System.Xml.Linq;


namespace GNPXcore{

		using tuple4 = (int,int,int,int);
		using tuple381 = (int,int,UInt128);

// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
//    under development (GNPXv5.1)
// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

	//..5..3....1.9..2....7.4...6.6.1...8.......4.3....37.5..59......8..2.....4....6...
	//625713894314968275987542136563194782798625413142837659259481367836279541471356928 

    public partial class Firework_TechGen: AnalyzerBaseV2{

        public bool Firework_Quadruple( ){
			// ===== Prepare =====
			if( stageNoP != stageNoPMemo ){
				stageNoPMemo = stageNoP;
				base.AnalyzerBaseV2_PrepareStage();
				Prepare_Firework_TechGen();
			}
			debugPrint = false;	
			 
			// ===== Analize =====
			var FWAgg2_List = FireworkAgg_List.FindAll(x => x.FreeBC>=2);
						//FWAgg2_List.ForEach( P=> WriteLine(P) );

			if( FWAgg2_List.Count>=2 ){
				Combination cmb = new( FWAgg2_List.Count(), 2 );  
				while( cmb.Successor() ){
					var ufw0 = FWAgg2_List[ cmb.Index[0] ];
					var ufw1 = FWAgg2_List[ cmb.Index[1] ];
					if( ( ufw0.FreeB & ufw1.FreeB ) != 0 )  continue;	// No overlapping digits
					if( ufw0.rc12B81 != ufw1.rc12B81 )  continue;		// Leafs matches

					bool solfound = Firework_Quadruple_SolResult( ufw0, ufw1 );
					if( !solfound )  continue;
					if( pAnMan.IsSolutionValid_Analyzer() )  return true; // @is Valid
				}
			}

			return false;
		}

		private bool Firework_Quadruple_SolResult( UFirework ufw0, UFirework ufw1 ){	
			int FreeBa=ufw0.FreeB, FreeBb=ufw1.FreeB;
			UInt128 leaf=ufw0.rc12B81;

			var (rc1, rc2) = leaf.Get_rc1_rc2();
			UCell UC0a=pBOARD[ufw0.rcStem],  UC0b=pBOARD[ufw1.rcStem], UC1=pBOARD[rc1], UC2=pBOARD[rc2];
			
			UC0a.Set_CellBKGColor(SolBkCr);
			UC0b.Set_CellBKGColor(SolBkCr);
			UC1.Set_CellBKGColor(SolBkCr2);
			UC2.Set_CellBKGColor(SolBkCr2);

			string st_Stem = $"{ufw0.rcStem.ToRCString()}#{FreeBa.ToBitStringNZ(9)} {ufw1.rcStem.ToRCString()}#{FreeBb.ToBitStringNZ(9)}";
			string st_Leaf = $"{rc1.ToRCString()}#{UC1.FreeB.ToBitStringNZ(9)}  {rc2.ToRCString()}#{UC2.FreeB.ToBitStringNZ(9)}";

			int FreeBT = FreeBa | FreeBb;
			UC0a.CancelB = UC0a.FreeB.DifSet(FreeBa);
			UC0b.CancelB = UC0a.FreeB.DifSet(FreeBb);
			UC1.CancelB = UC1.FreeB.DifSet(FreeBT);
			UC2.CancelB = UC2.FreeB.DifSet(FreeBT);
			
			if( pBOARD.Any(p=>p.CancelB>0) )  SolCode = 2;
			else{ pBOARD.ForEach( p=> { if( p.ECrLst!=null ) p.ECrLst.Clear() ; } ); }

			Result     = $"Firework_Quadruple Stem:{st_Stem} Leaf:{st_Leaf}";
			ResultLong = $"Firework_Quadruple\n  Stem : {st_Stem}\n  Leaf : {st_Leaf}";

			return (SolCode==2);
		}
	}
}