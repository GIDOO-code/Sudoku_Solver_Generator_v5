using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;
using static System.Math;
using System.IO;

using GIDOO_space;
using static System.Net.Mime.MediaTypeNames;
using static System.Net.WebRequestMethods;
using System.Diagnostics;
using System.Xml.Linq;


namespace GNPXcore{
// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
//    under development (GNPXv5.1)
// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*

/*
	//The New Sudoku Players' Forum, �wFireworks�x,
	// http://forum.enjoysudoku.com/fireworks-t39513.html
	//http://forum.enjoysudoku.com/fireworks-t39513-45.html

	+-------+-------+-------+
	| 9 . . | . 3 7 | . 8 . |
	| . 7 . | 1 . . | . . 9 |
	| 5 . . | 2 . . | . . . |
	+-------+-------+-------+
	| . 6 . | . . 5 | . . 8 |
	| 4 . . | . . . | . . 7 |
	| . . . | . . . | 2 3 . |
	+-------+-------+-------+
	| 7 . 5 | . . . | . . . |
	| . 2 . | . . 6 | . 9 . |
	| 6 . 9 | . 4 . | 5 . 1 |
	+-------+-------+-------+
	Heartline Roll - shye
	skfr 8.6
	9...37.8..7.1....95..2......6...5..84.......7......23.7.5.......2...6.9.6.9.4.5.1
	912437685376158429584269713263715948498623157157984236745391862821576394639842571

	.------------------.----------------------.-------------------.
	| 9    14    1246  |*x456    3      7     | 146    8    *25   |
	| 238  7     23468 |  1      568    48    | 346    25    9    |
	| 5    1348  13468 |  2      689    489   | 13467  1467  346  |
	:------------------+----------------------+-------------------:
	| 123  6     1237  |  3479   1279   5     | 149    14    8    |
	| 4    59    1238  |  3689   12689  12389 | 169    156   7    |
	| 18   59    178   | x46789  16789  1489  | 2      3    x46-5 |
	:------------------+----------------------+-------------------:
	| 7    1348  5     |  389    1289   12389 | 3468   246   2346 |
	| 138  2     1348  |  3578   1578   6     | 3478   9     34   |
	| 6    38    9     |  378    4      238   | 5      27    1    |
	'------------------'----------------------'-------------------'

dual firework l-wing

fireworks on 4&6 in r6c4b5
5r1c9 = (5-4|6)r1c4 = 46r6c49
-5r6c9 stte

perhaps easiest to explain in words: the 5 in r1 is either in c9 (-5r6c9) or c4 turning the firework into a hidden pair (-5r6c9)
you can also use 5 in c9 instead for this puzzle specifically
this is the most bare-bones deduction i've come across using fireworks, it's only 5 truths which is less than everything else so far!
*/

// GNPX original 20240510
// ...39.7...8.7...63..7.8.......6.83..82.....49..19.2.......1.8..74...3.5...8.59...
// ...39.7...8.72..63..7.8.....7.6483..823.7.6494619325......178..74.863.5...8.59...  step14:
// 156394728984725163237186495579648312823571649461932587695217834742863951318459276

    public partial class Firework_TechGen: AnalyzerBaseV2{
        public bool Firework_LWing( ){
			// ===== Prepare =====
			if( stageNoP != stageNoPMemo ){
				stageNoPMemo = stageNoP;
				base.AnalyzerBaseV2_PrepareStage();
				Prepare_Firework_TechGen();
			}
			debugPrint = false;	
			 
			// ===== Analize =====
			var FWAgg2_List = FireworkAgg_List.FindAll(q=> q.sw && q.FreeBC==2);	// Dual Firework
					//FWAgg2_List.ForEach( P=> WriteLine(P) );

			//*** Select fwStem
			foreach( UFirework fwStem in FWAgg2_List ){												// [1] Select fwStem
					//WriteLine( $"\n fwStem:{fwStem}" );

				//*** Select fwAssist
				foreach( UFirework fwAssist in Firework_List.
					Where( p=> p.sw && p.rc12B81==fwStem.rc12B81 && p.rcStem!=fwStem.rcStem) ){
					//WriteLine( $"fwAssist:{fwAssist}" );

					int no = fwAssist.FreeB.BitToNum();
					if( (BOARD81b9[no] & fwAssist.rc12B81).BitCount() != 2 )  continue;

					bool solfound = Firework_Dual_LWing_s_SolResult( fwStem, fwAssist );
					if( !solfound )  continue;

					if( pAnMan.IsSolutionValid_Analyzer() )  return true; // @is Valid
				}
			}
/*
			var queryLeaf = FireworkAgg_List.GroupBy(x => x.rc12B81);
			foreach( var fwLeaf in queryLeaf ){
					fwLeaf.ToList().ForEach( P=> WriteLine(P) );

				foreach( UFirework fwStem in fwLeaf.Where(p=>p.FreeBC==2) ){
					UCell UC1=pBOARD[fwStem.rc1], UC2=pBOARD[fwStem.rc2];
					if( UC1.FreeBC!=2 && UC2.FreeBC!=2 )  continue;
					WriteLine( $"\nfwStem:{fwStem}" );

					foreach( UFirework fwAssist in fwLeaf.Where( p=> p.sw && p.FreeBC==1 & fwStem.rcStem!=p.rcStem) ){
						WriteLine( $"fwAssist:{fwAssist}" );

						bool solfound = Firework_Dual_LWing_s_SolResult( fwStem, fwAssist );
						if( !solfound )  continue;
						if( pAnMan.IsSolutionValid_Analyzer() )  return true; // @is Valid
					}
				}
			}
*/
			return false;
		}

		private bool Firework_Dual_LWing_s_SolResult( UFirework fwStem, UFirework fwAssist ){	
			int   rcStem=fwStem.rcStem, FreeB=fwStem.FreeB, FreeBLeaf=fwAssist.FreeB;

			UCell UCStem=pBOARD[rcStem],  UC1=pBOARD[fwStem.rc1], UC2=pBOARD[fwStem.rc2];
			UCell UCAssist=pBOARD[fwAssist.rcStem];
			if( UC1.FreeBC==3 )  UC1.CancelB = UC1.FreeB & fwAssist.FreeB;
			if( UC2.FreeBC==3 )  UC2.CancelB = UC2.FreeB & fwAssist.FreeB;
			if( pBOARD.All(p=>p.CancelB==0) )  return false;
			SolCode = 2;

			//public void Set_CellColorBkgColor_noBit( int noB, Color clr, Color clrBkg ){
			UCStem.Set_CellColorBkgColor_noBit( FreeB, AttCr, SolBkCr);
			UC1.Set_CellColorBkgColor_noBit( FreeB, AttCr, SolBkCr);
			UC2.Set_CellColorBkgColor_noBit( FreeB, AttCr, SolBkCr);
			UCAssist.Set_CellColorBkgColor_noBit( fwAssist.FreeB, AttCr, SolBkCr2);

			string st_fw = $"{fwStem.rcStem.ToRCString()}#{fwStem.FreeB.ToBitStringNZ(9)}";
			string st_Leaf = $"{UC1.rc.ToRCString()}#{UC1.FreeB.ToBitStringNZ(9)} {UC2.rc.ToRCString()}#{UC2.FreeB.ToBitStringNZ(9)}";
			string st_Assist = $"{UCAssist.rc.ToRCString()}#{UCAssist.FreeB.ToBitStringNZ(9)}";
			string st_Exclude = "";
			if( UC1.CancelB>0 )  st_Exclude = $"{UC1.rc.ToRCString()}#{fwAssist.FreeB.ToBitStringNZ(9)}";
			if( UC2.CancelB>0 )  st_Exclude += $"{UC2.rc.ToRCString()}#{fwAssist.FreeB.ToBitStringNZ(9)}";

			Result     = $"Firework_LWing Stem:{st_fw} Leaf:{st_Leaf} Assist:{st_Assist} Exclude:{st_Exclude}";
			ResultLong = $"Firework_LWing\n  Stem : {st_fw}\n  Leaf : {st_Leaf}\n  Assist : {st_Assist}\n  Exclude : {st_Exclude}";

			return (SolCode==2);
		}
	}
}