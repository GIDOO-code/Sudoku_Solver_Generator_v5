using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;
using System.IO;
using System.Text;
using System.Security.Policy;
using static GNPXcore.Firework_TechGen;

namespace GNPXcore{

    public partial class Exocet_TechGen: AnalyzerBaseV2{
        static private   UInt128 qZero  = UInt128.Zero;
        static private   UInt128 qOne   = UInt128.One; 
		private int stageNoPMemo = -9;

		public List<UFirework> Exocet_List;	

		static List<Exocet_Pattern> BasicControlPatternList;

		private UInt128		  BOARD81b;
		private CellLinkMan   CeLKMan;
		internal bool		  debugPrint = false;

		static Exocet_TechGen(){

		}

		public Exocet_TechGen( GNPX_AnalyzerMan pAnMan ): base(pAnMan){ }

		public void Prepare_Exocet_TechGen(){
			CeLKMan = new CellLinkMan(pAnMan);
			CeLKMan.Initialize();
            bool lkExtB = (bool)GNPX_App.GMthdOption["UCellLinkExt"];
            CeLKMan.PrepareCellLink(1+2, lkExtB);    //StrongLink
		}

		private IEnumerable<(int,int,UInt128,int)> IEGet_BaseCells( ){
			for( int dir=0; dir<2; dir++ ){

				for( int rc0=0; rc0<81; rc0++ ){
					int b0 = rc0.ToBlock(); 

					UInt128 baseCells = (dir==0)? HouseCells81[rc0/9]: HouseCells81[rc0%9+9];
					baseCells = (baseCells & HouseCells81[b0+18] & BOARD81b ).Reset(rc0);

					var rcList = baseCells.BitToNumList(81);
					if( rcList==null || rcList.Count<=1 )  continue;

					UCell UC0=pBOARD[rcList[0]], UC1=pBOARD[rcList[1]];
					int FreeB0 = UC0.FreeB | UC1.FreeB;
					int FreeBC = FreeB0.BitCount();
					if( FreeBC<3 || FreeBC>4 )  continue;

					yield return (dir, rc0, baseCells, FreeB0); 
				}
			}
			yield break;
		}

		private	int Get_rc_Companion( int dir, int rc0, int rc_target,int FreeB ){
			UInt128 com = HouseCells81[ rc_target.ToBlock()+18 ] .DifSet( ConnectedCells81[rc0]);
			int hh = (dir==0)? (rc_target%9)+9: rc_target/9;
			com = (com & HouseCells81[hh]).DifSet(UInt128.One<<rc_target);
			int rc_Companion = com.FindFirst_rc();

			UCell UC = pBOARD[rc_Companion];
			int testFreeB = (UC.No>0)? (1<<UC.No-1): FreeB;
			rc_Companion = ((testFreeB & FreeB) == 0)? rc_Companion: -rc_Companion;
					if(debugPrint){
						string st2 = $"dir:{dir}  rc_target->Companion : {rc_target.ToRCString()}";
						st2 += $" -> {Abs(rc_Companion).ToRCString()}";
						if( rc_Companion<0 )  st2 += " ---";
						WriteLine(st2);
					}
			return  rc_Companion;
		}


		class Exocet_Pattern{
			public UInt128 Base;
			public UInt128 Terget;
			public UInt128 CoverLine;
		}
	}

}