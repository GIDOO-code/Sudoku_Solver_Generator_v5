using System;
using System.Collections.Generic;
using System.Linq;
using static System.Diagnostics.Debug;
using System.Windows.Media;
using static System.Math;
using System.IO;

using GIDOO_space;
using static System.Net.Mime.MediaTypeNames;
using static System.Net.WebRequestMethods;
using System.Collections;
using static GNPXcore.Firework_TechGen;
using System.Windows.Documents;


namespace GNPXcore{
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
	//    under development (GNPXv5.1)
	// *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*


	// The New Sudoku Players' Forum, �wExotic patterns a resume�x,
	// http://forum.enjoysudoku.com/exotic-patterns-a-resume-t30508.html
	// The New Sudoku Players' Forum, �wJExocet Pattern Definition�x,
	// http://forum.enjoysudoku.com/jexocet-pattern-definition-t31133.html

	// ..5....38.3....4..42.3.........6..7929..5...1..38..2......1...6..45..9..9....7.5.
	// 715429638638175492429386715841263579296754381573891264357912846164538927982647153 ... elapsed time:6ms

	// ..4.2...9.32.9....5....3.4...3..8.5....65.1..........7.4...2.9.3..7....58..91.6.. ... transposed
	// 764825319132497568589163742413278956278659134956341287647532891391786425825914673

	// ..7.2...493....6..6..3............5.2...1...8..69..4....37..9...2..5...1.....8...

	//Help on using Junior Exocets
	//http://forum.enjoysudoku.com/help-on-using-junior-exocets-t34669.html
	// .2.34....4...5......6..17..5..2......3.....4...1..68....9....7....1..9.......9.68 ... step6
	// 127348596493657182856921734568294317732815649941736825289563471674182953315479268

	// The New Sudoku Players' Forum
	// http://forum.enjoysudoku.com/mutant-exocet-t39245.html
	// ..3.1...5.8.7.........2.4........1...9.4...8.2.......3476.3..5..5.879..........7.
	// 723914865984765312615328497547683129391452786268197543476231958152879634839546271 ... elapsed time:212ms

    public partial class Exocet_TechGen: AnalyzerBaseV2{


        public bool Junior_Exocet( ){
			// ===== Prepare =====
			if( stageNoP != stageNoPMemo ){
				stageNoPMemo = stageNoP;
				base.AnalyzerBaseV2_PrepareStage();

				Prepare_Exocet_TechGen();
			}
			BOARD81b = pBOARD.Create_bitExp128();
			debugPrint = false;


			// ***** Base cells (rc0:StemCell)
			foreach( var (dir,rc0,baseCells,FreeB0) in IEGet_BaseCells() ){

				int b0 = rc0.ToBlock();
							if(debugPrint) WriteLine( $"\n dir:{dir}  <<rc0:{rc0}>>   b0:{b0}  baseCells:{baseCells.ToBitString81N()}" );

				// ***** Base SLine
				int house_rc0 = (dir==0)? (rc0%9+9): (rc0/9); 
				UInt128 SLine0 = HouseCells81[house_rc0]. DifSet( HouseCells81[b0+18] );
							if(debugPrint) WriteLine( $"    dir:{dir}  SLine:{SLine0.ToBitString81N()}" );

				// ***** Target Blocks					
				int  b1=0, b2=0, shift=b0/3*3;
				if( dir==0 ){ b1=(b0+1)%3+shift; b2=(b0+2)%3+shift; }
				else{         b1=(b0+3)%9;		 b2=(b0+6)%9; }
							if(debugPrint) WriteLine( $"   dir:{dir}  <<rc0:{rc0:00}>>   b0:{b0}   (b1,b1):({b1},{b2})" );

			// ***** Target Cells
				foreach( var (rc1,rc2) in _IEGet_TargetCells(dir,rc0,b1,b2,FreeB0) ){
							if(debugPrint) WriteLine( $"    (rc_t1,rc_t2) : {rc1.ToRCString()}, {rc2.ToRCString()}" ); 

					var fwList = _Get_fakeUFirework(dir, rc1, b1, SLine0);
					var fwList2 = _Get_fakeUFirework(dir, rc2, b2, SLine0);
					fwList.AddRange(fwList2);

				// ***** Verification
					if( !Verification(FreeB0,SLine0,fwList) )  continue;

					bool solfound = JExocet_SolResult( baseCells, rc1, rc2, fwList );
					if( !solfound ) continue;

					if( pAnMan.IsSolutionValid_Analyzer() )  return true; // @is Valid
				}
			}
			return false;


			// ==============================================================================
			IEnumerable<(int,int)> _IEGet_TargetCells( int dir, int rc0, int b1, int b2, int FreeB ){
				UInt128 targetBlockt1_81b = HouseCells81[b1+18] .DifSet(ConnectedCells81[rc0]);
				UInt128 targetBlockt2_81b = HouseCells81[b2+18] .DifSet(ConnectedCells81[rc0]);

				foreach( int rc_targetCell1 in targetBlockt1_81b.IEGet_rc().Where(rc=> (pBOARD[rc].FreeB&FreeB)>0)  ){
					int rc_Companion1 = Get_rc_Companion(dir, rc0, rc_targetCell1, FreeB );
					if( rc_Companion1<0 )  continue;

					foreach( int rc_targetCell2 in targetBlockt2_81b.IEGet_rc().Where(rc=> (pBOARD[rc].FreeB&FreeB)>0) ){
						int rc_Companion2 = Get_rc_Companion(dir, rc0, rc_targetCell2, FreeB );
						if( rc_Companion2<0 )  continue;

						yield return (rc_targetCell1, rc_targetCell2);
					}
				}
				yield break;
			}

			List<UFirework> _Get_fakeUFirework( int dir, int rcX, int bX, UInt128 sLine0 ){
				int houseX = (dir==0)? (rcX%9+9): (rcX/9); 
				UInt128 SLineX = HouseCells81[houseX]. DifSet( HouseCells81[bX+18] );

				List<UFirework>  fwList = new(); 
				foreach( var LK1 in CeLKMan.CeLK81[rcX].Where(q=> SLineX.IsHit(q.rc2) ) ){
					if( (SLineX & BOARD81b9[LK1.no]).BitCount() != 1 )  continue;			// @@@ LK1 ensures strong links.

					int rcStem = LK1.rc2;
					if( CeLKMan.CeLK81[rcStem] == null )  continue; 

					foreach( var LK2 in CeLKMan.CeLK81[rcStem].Where(q=> q.no==LK1.no && sLine0.IsHit(q.rc2) ) ){
						UFirework UFW = new( false, rcStem, LK1.no, rcX, LK2.rc2 );
						if( fwList.Count()>0 && fwList.Any(p=> UFW.Equals(p)) )  continue;
							//WriteLine( $"@@@   UFW:{UFW}" );
						fwList.Add(UFW);
					}
				}
				if(debugPrint && fwList.Count()>0 )  fwList.ForEach(p=> WriteLine(p));
				return  fwList;
			}

			bool Verification( int FreeB0, UInt128 SLine0, List<UFirework> f1List ){
				foreach( var no in FreeB0.IEGet_BtoNo() ){
					UInt128 SLineNo = BOARD81b9[no] & SLine0;
					foreach( var fw in f1List.Where(p=>p.FreeB.IsHit(no)) ){
						SLineNo = SLineNo.Reset(fw.rc1); // Reset both ends of the Firework without considering.
						SLineNo = SLineNo.Reset(fw.rc2);
					}
					if( SLineNo.IsNotZero() )  return  false;
				}
				return true;
			}
		}

		private bool JExocet_SolResult( UInt128 baseCells, int rc1, int rc2, List<UFirework> fwList ){
			var rcList = baseCells.BitToNumList(81);
			UCell UC0=pBOARD[rcList[0]], UC1=pBOARD[rcList[1]];	
			int FreeB0 = UC0.FreeB | UC1.FreeB;
			
			UCell UCtg1=pBOARD[rc1], UCtg2=pBOARD[rc2];

			int FreeB1 = (fwList==null)? -1: FreeB0.DifSet( fwList.Aggregate(0, (p,q)=> p|q.FreeB) );  
			if( FreeB1!=0 )  return false;

			UCtg1.CancelB = UCtg1.FreeB.DifSet(FreeB0);
			UCtg2.CancelB = UCtg2.FreeB.DifSet(FreeB0);
			if( pBOARD.All(p=>p.CancelB==0) )  return false;

			SolCode = 2;

			UC0.Set_CellColorBkgColor_noBit( FreeB0, AttCr, SolBkCr);
			UC1.Set_CellColorBkgColor_noBit( FreeB0, AttCr, SolBkCr);

			string stBase = $"{baseCells.ToRCStringComp()} #{FreeB0.ToBitStringNZ(9)}";
			string stTarget="";

			stTarget += $"{rc1.ToRCString()} ";
			UCtg1.Set_CellColorBkgColor_noBit( FreeB0, AttCr, SolBkCr2);
			UCtg2.Set_CellColorBkgColor_noBit( FreeB0, AttCr, SolBkCr2);
			fwList.ForEach( P=> pBOARD[P.rcStem].Set_CellColorBkgColor_noBit( FreeB0, AttCr, SolBkCr3) );

			Result     = $"Junior_Exocet Base:{stBase} Target:{stTarget}";
			ResultLong = $"Junior_Exocet\n   Base : {stBase}\n Target : {stTarget}";

			return true;
		}

	}
}