﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;
//using GIDOO_Lib;
//using OpenCvSharp;

namespace GIDOO_space{
    public static class G{
        static public char[] _sep={' ',',','\t'};
        static public char[] _sepC={','};
        static public string _backupDir="backupDir";
		static public string GNPXvX = "GNPXv5 2024";  //"GNPXv5 " + DateTime.Now.Year;

        static public readonly Color[] _ColorsLst2 = new Color[]{
                Colors.Red, Colors.Blue, Colors.Tomato,
                Colors.DarkViolet, Colors.Lime, Colors.Magenta,
                Colors.DarkGreen, Colors.DodgerBlue, Colors.DarkOrange,
            };
    }
}
