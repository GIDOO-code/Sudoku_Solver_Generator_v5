using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;
using System.Xml.Serialization;

using GIDOO_space;
using System.Windows.Documents;

namespace GNPXcore {
    //ALS(Almost Locked Set) 
    // ALS is a state where there are "n+1 candidate digits" in "n cells" belonging to the same house. 
    // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page26.html

  #region UALS
    [Serializable]


    public class UALS: UAnLS, IComparable{

        public UALS(){ }

        public UALS( int ID, int FreeB, List<UCell> UCellLst ): base(ID, FreeB, UCellLst ){
          //this.Level     = 1;
			this.LockedNoDir = null;
		   
			this.bitExp    = UCellLst.Aggregate( UInt128.Zero, (p,q)=> p| UInt128.One<<q.rc );
			this.connectedCellsB81 = UCellLst.Aggregate( UInt128.Zero, (p,q)=> p| pConnectedCells81[q.rc] );
			//Set_BitExpression( );
        }
/*
		public int  rcbAnd9_wk( int no ){   // --> UAnLS
			int noB=1<<no;
			int rcbAnd = UCellLst.Where(p=>(p.FreeBwk&noB)>0).						// Select cells with no as an element.
						 Aggregate(0x7FFFFFF, (a,b) => a & b.rc.rcbFrame_Value() );		// house(rcb) common to all elements.
			if( rcbAnd==0x7FFFFFF ) return 0;
				//UCellLst.ForEach( p=> WriteLine( $"b.rc:{p.rc.rcbFrame_Value().rcbToBitString27()}" ) );
				//WriteLine( $"rcbAnd:{rcbAnd.rcbToBitString27()}" );
			return rcbAnd;
		}
*/
        public List<(UALS,int)> ConnectedALS; //[ATT] ... The second term is a bit representation.
        public (UALS,int)      preALS_no = (null,-9);

		public void RestoreFreeBwk( ) => UCellLst.ForEach( P => P.FreeBwk=P.FreeB ); 

        public UInt128 ToBitExpression128( int filter_FreeB ){
            UInt128 BP128 = UInt128.Zero;
            foreach( var P in  UCellLst.Where( p=>(p.FreeB&filter_FreeB)>0 ) ) BP128 |= UInt128.One<<P.rc;
            return BP128;
        }

//        public override int GetHashCode() => UCellLst.Aggregate(0,(p,q)=> p^q.GetHashCode() );  //Just hashing the cell distribution is enough

/*
        public int CompareTo( object obj ){
            UALS UB = obj as UALS;
            if( this.Level!=UB.Level ) return (this.Level-UB.Level);
            if( this.Size!=UB.Size )   return (this.Size-UB.Size);

            if( this.FreeB!=UB.FreeB ) return ( this.sortkey-UB.sortkey );
            int bitW = (this.bitExp==UB.bitExp)? 0: (this.bitExp>UB.bitExp)? 1: -1;
            return bitW;
        }
*/
/*
		private UInt128[] Create_connectedCellsB81_9( ){			//..... FreeBwk
            UInt128[] B128 = new UInt128[9];
			foreach( int no in FreeB.IEGet_BtoNo() ){
				int noB = 1<<no;
				UInt128 Utmp = UInt128.MaxValue;
				foreach( var U in UCellLst ){
					if( (U.FreeB&noB) != 0 )  Utmp &= pConnectedCells81[U.rc];
				}
				B128[no] = Utmp;
			}
            return B128;
        }
*/
		public  string ToString_FreeBwk(){
			string st = $"UALS << ID:{ID} >>  [ Size:{Size} Level:{Level} ]";
			st += $"  FreeB:{FreeB.ToBitString(9)}  FreeBwk:{FreeBwk.ToBitString(9)}\n";
			st += $"         bitExp {bitExp.ToBitString81N()}\r";
			for(int k=0; k<UCellLst.Count; k++){
				st += "------";
				int rcW = UCellLst[k].rc;
				st += $" rc:{rcW.ToRCString()}";
				st += $" FreeBwk:{UCellLst[k].FreeBwk.ToBitString(9)}";
				st += $" rcb:b{(rcbBlk).ToBitString(9)}";
				st += $" c{rcbCol.ToBitString(9)}";
				st += $" r{rcbRow.ToBitString(9)}";
				//st += $" connectedCellsB:{connectedCellsB81.ToBitString81N()}";
			  	st += "\n";
			}
            return st;
        }

        public string ToStringA(){
            string st = $"<> UALS ID:{ID} Size:{Size} Level:{Level}  FreeB:{FreeB.ToBitString(9)} rc:{ToStringRCN()}";
            return  st;
        }

        public string ToStringRCN( ){
            string st="";
            UCellLst.ForEach( p =>{  st += $" {p.rc.ToRCString()}"; } );
            st = st.ToString_SameHouseComp()+" #"+FreeB.ToBitStringN(9);
            return st;
        }
        public string ToStringRC( ){
            string st="";
            UCellLst.ForEach( p =>{  st += $" {p.rc.ToRCString()}"; } );
            st = st.ToString_SameHouseComp();
            return st;
        }
    }
  #endregion UALS


  #region Link_CellALS
        // Cell-ALS Link
    public class Link_CellALS: IComparable{
//        static public UInt128[]    pConnectedCells81{ get{ return AnalyzerBaseV2.ConnectedCells81; } }
  
        public readonly UCell UC;
        public readonly UALS  ALS;
        public readonly int   nRCC=-1; //no:0..8 (not bit representation)

        public int            noBcand;

        public Link_CellALS( UCell UC, UALS ALS, int nRCC ){
            this.UC=UC; this.ALS=ALS; this.nRCC=nRCC;
        }
        public  override bool Equals( object obj ){
            var A = obj as Link_CellALS;
            return (this.ALS.ID==A.ALS.ID);
        }

        public int CompareTo( object obj ){
            Link_CellALS A = obj as Link_CellALS;
            return (this.ALS.ID-A.ALS.ID);
        }
        public int CompareTo( ){
            return (this.ALS.ID);
        }

        public override string ToString(){
            string st = $"Link_CellALS nRCC:#{nRCC+1}";
            st += " UCell:"+UC+"\rALS:"+ ALS;
            return st;
        }
        public override int GetHashCode(){ return base.GetHashCode(); }


    }
  #endregion Link_CellALS

}
